package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import com.example.live.LiveSessionManager
import com.example.live.ZoyaState
import com.example.tools.SmartIntentDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ZoyaSpeechManager(
    private val context: Context,
    private val liveSessionManager: LiveSessionManager,
    private val intentDispatcher: SmartIntentDispatcher,
    private val onInterruptPlayback: () -> Unit
) {
    companion object {
        private const val TAG = "ZoyaSpeechManager"

        private val WAKE_PATTERNS = listOf(
            Regex("""\b(?:hey\s+|ok\s+|hi\s+)?zoya\b""", RegexOption.IGNORE_CASE),
            Regex("""\bzoya\b""", RegexOption.IGNORE_CASE)
        )

        private val INTERRUPT_COMMANDS = setOf(
            "stop", "zoya stop", "shut up", "be quiet", "cancel", "hush", "wait", "hold on", "pause", "quiet"
        )
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.Main)

    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false
    private var isPaused = false

    @Volatile
    private var lastRecognizedTime = 0L

    fun start() {
        isPaused = false
        mainHandler.post {
            initAndStartRecognizer()
        }
    }

    fun pause() {
        isPaused = true
        mainHandler.post {
            stopRecognizer()
        }
    }

    fun resume() {
        isPaused = false
        mainHandler.post {
            initAndStartRecognizer()
        }
    }

    fun destroy() {
        isPaused = true
        mainHandler.post {
            stopRecognizer()
            speechRecognizer?.destroy()
            speechRecognizer = null
        }
    }

    private fun initAndStartRecognizer() {
        if (isPaused) return
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.w(TAG, "SpeechRecognizer is not available on this device.")
            return
        }

        try {
            if (speechRecognizer == null) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(createListener())
                }
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }

            speechRecognizer?.startListening(intent)
            isListening = true
            Log.d(TAG, "SpeechRecognizer started listening.")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start speech recognizer", e)
            scheduleRestart(1000)
        }
    }

    private fun stopRecognizer() {
        try {
            isListening = false
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping recognizer", e)
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        if (isPaused) return
        mainHandler.removeCallbacksAndMessages(null)
        mainHandler.postDelayed({
            if (!isPaused) {
                initAndStartRecognizer()
            }
        }, delayMs)
    }

    private fun createListener(): RecognitionListener {
        return object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                Log.v(TAG, "onReadyForSpeech")
            }

            override fun onBeginningOfSpeech() {
                Log.d(TAG, "User speech started.")
                val currentState = liveSessionManager.zoyaState.value
                if (currentState == ZoyaState.SPEAKING) {
                    // Possible barge-in in progress!
                }
            }

            override fun onRmsChanged(rmsdB: Float) {}

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                Log.d(TAG, "User speech ended.")
            }

            override fun onError(error: Int) {
                Log.d(TAG, "SpeechRecognizer error: $error")
                isListening = false
                val restartDelay = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> 150L
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                    SpeechRecognizer.ERROR_AUDIO -> 600L
                    else -> 400L
                }
                scheduleRestart(restartDelay)
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
                if (matches.isEmpty()) return
                val text = matches[0].trim()
                handleRealtimeSpeech(text, isFinal = false)
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
                if (matches.isNotEmpty()) {
                    val text = matches[0].trim()
                    handleRealtimeSpeech(text, isFinal = true)
                }
                scheduleRestart(150)
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }

    private fun handleRealtimeSpeech(utterance: String, isFinal: Boolean) {
        if (utterance.isBlank()) return
        val lower = utterance.lowercase().trim()

        val currentState = liveSessionManager.zoyaState.value

        // 1. Natural Interruption / Barge-In while AI is speaking
        if (currentState == ZoyaState.SPEAKING || liveSessionManager.isTtsSpeaking) {
            // Echo guard: If the recognized words are simply Zoya's own speech echoing into the mic, drop it!
            val currentSpoken = liveSessionManager.currentSpokenUtterance?.lowercase()
            if (currentSpoken != null && isEchoOfOwnVoice(lower, currentSpoken)) {
                Log.v(TAG, "Filtered acoustic echo of own TTS: '$lower'")
                return
            }

            // Check if user spoke an intentional interruption command or new sentence
            val isExplicitStop = INTERRUPT_COMMANDS.any { lower.contains(it) }
            val hasWakeWord = WAKE_PATTERNS.any { it.containsMatchIn(lower) }
            val hasSubstantialSpeech = lower.split(" ").size >= 2

            if (isExplicitStop || hasWakeWord || hasSubstantialSpeech) {
                Log.i(TAG, "⚡ Natural interruption triggered by user voice: '$utterance'")
                onInterruptPlayback()
                liveSessionManager.onLocalBargeIn()

                // If user said "Zoya, stop" or "stop", acknowledge and stay in listening mode
                if (isExplicitStop && (lower.endsWith("stop") || lower == "stop")) {
                    liveSessionManager.speakTextDirect("Stopped.")
                    return
                }

                // If user said a new command like "Zoya, stop. Open YouTube" or "Open YouTube"
                val cleanedUtterance = lower.replace(Regex("""^(?:zoya\s*,?\s*)?(?:stop|wait|cancel)[.,\s]*"""), "").trim()
                if (cleanedUtterance.isNotBlank()) {
                    executeUtterance(cleanedUtterance)
                }
                return
            }
        }

        // 2. Wake Word Handling when in STANDBY mode
        if (currentState == ZoyaState.STANDBY) {
            val containsWake = WAKE_PATTERNS.any { it.containsMatchIn(lower) }
            if (containsWake) {
                Log.i(TAG, "Wake word 'Zoya' detected in standby mode! Utterance: '$utterance'")
                // Strip wake word
                val commandAfterWake = intentDispatcher.stripWakeWord(utterance)

                if (commandAfterWake.isBlank()) {
                    // User just said "Zoya" -> activate active listening mode
                    liveSessionManager.speakTextDirect("Yes?")
                } else if (isFinal || commandAfterWake.split(" ").size >= 2) {
                    // User said "Zoya, open YouTube" in one breath!
                    executeUtterance(commandAfterWake)
                }
                return
            } else {
                // Ignore background conversation in standby mode
                return
            }
        }

        // 3. Normal Active Utterance Handling
        if (isFinal) {
            val now = System.currentTimeMillis()
            if (now - lastRecognizedTime < 600) return
            lastRecognizedTime = now
            executeUtterance(utterance)
        }
    }

    private fun executeUtterance(rawText: String) {
        com.example.ZoyaForegroundService.activeService?.resetProactiveTimer()
        val clean = intentDispatcher.stripWakeWord(rawText)
        if (clean.isBlank()) return

        scope.launch {
            try {
                when (val result = intentDispatcher.dispatch(clean)) {
                    is SmartIntentDispatcher.DispatchResult.Handled -> {
                        liveSessionManager.speakTextDirect(result.spokenResponse)
                    }
                    is SmartIntentDispatcher.DispatchResult.NeedsConfirmation -> {
                        liveSessionManager.speakTextDirect(result.spokenPrompt)
                    }
                    is SmartIntentDispatcher.DispatchResult.FallthroughToAi -> {
                        // Forward to Gemini Live or AI for complex reasoning
                        liveSessionManager.sendTextMessage(result.cleanUtterance)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error executing utterance", e)
                liveSessionManager.speakTextDirect("Sorry, I ran into an issue handling that.")
            }
        }
    }

    private fun isEchoOfOwnVoice(userSpeech: String, aiUtterance: String): Boolean {
        if (aiUtterance.contains(userSpeech) || userSpeech.contains(aiUtterance)) return true
        val speechWords = userSpeech.split(" ").filter { it.length > 2 }
        val aiWords = aiUtterance.split(" ").filter { it.length > 2 }
        if (speechWords.isEmpty()) return false
        val matchCount = speechWords.count { aiWords.contains(it) }
        return matchCount.toDouble() / speechWords.size >= 0.7
    }
}
