package com.example.voice

import android.util.Log

class VoiceLatencyTracker {

    companion object {
        private const val TAG = "ZoyaLatency"
    }

    private var speechStartTime = 0L
    private var speechEndTime = 0L
    private var firstChunkSentTime = 0L
    private var firstServerAudioReceivedTime = 0L
    private var playbackStartTime = 0L

    var lastMeasuredLatencyMs = 0L
        private set

    @Synchronized
    fun onUserSpeechStarted() {
        speechStartTime = System.currentTimeMillis()
        speechEndTime = 0L
        firstChunkSentTime = 0L
        firstServerAudioReceivedTime = 0L
        playbackStartTime = 0L
        Log.d(TAG, "⏱ [T0] User started speaking")
    }

    @Synchronized
    fun onFirstAudioChunkSent() {
        if (firstChunkSentTime == 0L) {
            firstChunkSentTime = System.currentTimeMillis()
            val delta = if (speechStartTime > 0) firstChunkSentTime - speechStartTime else 0
            Log.d(TAG, "⏱ [T1] First audio chunk dispatched to server (+${delta}ms from speech start)")
        }
    }

    @Synchronized
    fun onUserSpeechEnded() {
        speechEndTime = System.currentTimeMillis()
        val speechDuration = if (speechStartTime > 0) speechEndTime - speechStartTime else 0
        Log.d(TAG, "⏱ [T2] User finished speaking (Utterance duration: ${speechDuration}ms)")
    }

    @Synchronized
    fun onFirstServerAudioReceived() {
        if (firstServerAudioReceivedTime == 0L) {
            firstServerAudioReceivedTime = System.currentTimeMillis()
            val deltaFromSpeechEnd = if (speechEndTime > 0) firstServerAudioReceivedTime - speechEndTime else 0
            Log.i(TAG, "⚡ [T3] First server audio response received (+${deltaFromSpeechEnd}ms from speech end)")
        }
    }

    @Synchronized
    fun onPlaybackStarted() {
        if (playbackStartTime == 0L) {
            playbackStartTime = System.currentTimeMillis()
            val totalLatency = if (speechEndTime > 0) playbackStartTime - speechEndTime else 0
            lastMeasuredLatencyMs = totalLatency
            val bufferTime = if (firstServerAudioReceivedTime > 0) playbackStartTime - firstServerAudioReceivedTime else 0
            Log.i(TAG, "🔊 [T4] First audio rendered out of speaker! Total End-to-Speech latency: ${totalLatency}ms (Buffer delay: ${bufferTime}ms)")
        }
    }

    @Synchronized
    fun formatDiagnosticSummary(): String? {
        if (speechEndTime == 0L || playbackStartTime == 0L) return null
        val totalMs = playbackStartTime - speechEndTime
        val networkModelMs = if (firstServerAudioReceivedTime > speechEndTime) firstServerAudioReceivedTime - speechEndTime else 0
        return "⚡ Latency: ${totalMs}ms (API+Model: ${networkModelMs}ms)"
    }
}
