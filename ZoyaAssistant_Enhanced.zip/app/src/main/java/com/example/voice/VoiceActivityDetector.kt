package com.example.voice

import android.util.Log
import kotlin.math.abs
import kotlin.math.sqrt

class VoiceActivityDetector(
    private val sampleRate: Int = 16000,
    private val frameSize: Int = 1600, // 100ms per frame
    private val onSpeechStart: (preSpeechFrames: List<ShortArray>) -> Unit,
    private val onSpeechChunk: (chunk: ShortArray, rms: Double) -> Unit,
    private val onSpeechEnd: (speechDurationMs: Long) -> Unit,
    private val onBargeIn: () -> Unit
) {
    companion object {
        private const val TAG = "ZoyaVAD"

        // Baseline minimum RMS for speech detection (16-bit PCM: values range 0 - 32767)
        // Normal speech in 16-bit PCM is typically RMS 400 - 4000+
        // Background room noise is typically RMS 50 - 250
        const val DEFAULT_MIN_RMS_THRESHOLD = 450.0

        // Elevated threshold required to trigger barge-in while AI is actively speaking
        // This ensures speaker audio leakage does not cause false self-interruptions
        const val DEFAULT_BARGE_IN_RMS_THRESHOLD = 1200.0

        // Frames above threshold required to confirm speech (2 frames = 200ms)
        // Filters out clicks, keyboard taps, mic handling pops
        const val CONSECUTIVE_FRAMES_FOR_SPEECH = 2

        // Consecutive silence frames to declare end of speech (6 frames = 600ms)
        const val CONSECUTIVE_SILENCE_FRAMES_FOR_END = 6

        // Max pre-speech frames to buffer (3 frames = 300ms)
        const val PRE_SPEECH_BUFFER_SIZE = 3
    }

    enum class State {
        SILENCE,
        POSSIBLE_SPEECH,
        IN_SPEECH
    }

    private var currentState = State.SILENCE
    private var consecutiveSpeechFrames = 0
    private var consecutiveSilenceFrames = 0

    // Dynamic background noise floor tracking using Exponential Moving Average
    private var ambientNoiseRms = 120.0

    // Pre-speech ring buffer to avoid clipping the start of words
    private val preSpeechBuffer = ArrayDeque<ShortArray>(PRE_SPEECH_BUFFER_SIZE)

    private var speechStartTimeMs = 0L

    var isAiSpeaking: Boolean = false
    val isSpeaking: Boolean
        get() = currentState == State.IN_SPEECH

    @Synchronized
    fun processFrame(frame: ShortArray, length: Int) {
        if (length <= 0) return

        val rms = calculateRms(frame, length)

        // Adaptively update ambient noise estimate when in silence and AI is not speaking
        if (currentState == State.SILENCE && !isAiSpeaking) {
            // Smooth noise floor tracking (alpha = 0.05)
            if (rms < ambientNoiseRms * 1.5) {
                ambientNoiseRms = (0.95 * ambientNoiseRms) + (0.05 * rms)
            }
        }

        // Determine effective threshold
        val threshold = if (isAiSpeaking) {
            maxOf(DEFAULT_BARGE_IN_RMS_THRESHOLD, ambientNoiseRms * 4.0)
        } else {
            maxOf(DEFAULT_MIN_RMS_THRESHOLD, ambientNoiseRms * 2.2)
        }

        val isAboveThreshold = rms >= threshold

        // Save clone to pre-speech ring buffer
        val frameCopy = frame.copyOf(length)

        when (currentState) {
            State.SILENCE -> {
                updatePreSpeechBuffer(frameCopy)

                if (isAboveThreshold) {
                    consecutiveSpeechFrames = 1
                    currentState = State.POSSIBLE_SPEECH
                }
            }

            State.POSSIBLE_SPEECH -> {
                updatePreSpeechBuffer(frameCopy)

                if (isAboveThreshold) {
                    consecutiveSpeechFrames++
                    if (consecutiveSpeechFrames >= CONSECUTIVE_FRAMES_FOR_SPEECH) {
                        // Confirmed speech detected!
                        currentState = State.IN_SPEECH
                        speechStartTimeMs = System.currentTimeMillis()
                        consecutiveSilenceFrames = 0

                        if (isAiSpeaking) {
                            Log.i(TAG, "⚡ BARGE-IN DETECTED! RMS=$rms > Threshold=$threshold")
                            onBargeIn()
                        } else {
                            Log.d(TAG, "Speech Start confirmed (RMS=$rms, Ambient=$ambientNoiseRms)")
                        }

                        // Emit pre-speech buffer so leading consonants ("Hey", "Call") are intact
                        val preFrames = preSpeechBuffer.toList()
                        preSpeechBuffer.clear()
                        onSpeechStart(preFrames)

                        // Also emit the current frame
                        onSpeechChunk(frameCopy, rms)
                    }
                } else {
                    // False alarm (e.g. single click or short pop)
                    consecutiveSpeechFrames = 0
                    currentState = State.SILENCE
                }
            }

            State.IN_SPEECH -> {
                onSpeechChunk(frameCopy, rms)

                if (isAboveThreshold) {
                    consecutiveSilenceFrames = 0
                } else {
                    consecutiveSilenceFrames++
                    if (consecutiveSilenceFrames >= CONSECUTIVE_SILENCE_FRAMES_FOR_END) {
                        // User has finished speaking
                        val duration = System.currentTimeMillis() - speechStartTimeMs
                        Log.d(TAG, "Speech End detected after $duration ms")
                        currentState = State.SILENCE
                        consecutiveSpeechFrames = 0
                        consecutiveSilenceFrames = 0
                        onSpeechEnd(duration)
                    }
                }
            }
        }
    }

    private fun updatePreSpeechBuffer(frame: ShortArray) {
        if (preSpeechBuffer.size >= PRE_SPEECH_BUFFER_SIZE) {
            preSpeechBuffer.removeFirst()
        }
        preSpeechBuffer.addLast(frame)
    }

    @Synchronized
    fun reset() {
        currentState = State.SILENCE
        consecutiveSpeechFrames = 0
        consecutiveSilenceFrames = 0
        preSpeechBuffer.clear()
    }

    private fun calculateRms(buffer: ShortArray, length: Int): Double {
        var sumSquares = 0.0
        for (i in 0 until length) {
            val sample = buffer[i].toDouble()
            sumSquares += sample * sample
        }
        return sqrt(sumSquares / length)
    }
}
