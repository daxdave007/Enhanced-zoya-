package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val content: String,
    val category: String = "ADVICE", // "ADVICE", "PREFERENCE", "FACT", "RELATIONSHIP"
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "transcripts")
data class TranscriptEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val role: String, // "user", "zoya", "tool"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val latencyMs: Long? = null
)
