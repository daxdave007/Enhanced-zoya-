package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Database(
    entities = [MemoryEntity::class, TranscriptEntity::class],
    version = 1,
    exportSchema = false
)
abstract class ZoyaDatabase : RoomDatabase() {

    abstract fun zoyaDao(): ZoyaDao

    companion object {
        @Volatile
        private var INSTANCE: ZoyaDatabase? = null

        fun getDatabase(context: Context): ZoyaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ZoyaDatabase::class.java,
                    "zoya_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class ZoyaRepository(private val dao: ZoyaDao) {

    val allMemories: Flow<List<MemoryEntity>> = dao.getAllMemories()
    val activeMemories: Flow<List<MemoryEntity>> = dao.getActiveMemories()
    val allTranscripts: Flow<List<TranscriptEntity>> = dao.getAllTranscripts()

    suspend fun addMemory(content: String, category: String = "ADVICE"): Long {
        return dao.insertMemory(
            MemoryEntity(
                content = content,
                category = category,
                isActive = true
            )
        )
    }

    suspend fun deleteMemory(id: Long) {
        dao.deleteMemory(id)
    }

    suspend fun getActiveMemoriesSnapshot(): List<MemoryEntity> {
        return dao.getActiveMemoriesSnapshot()
    }

    suspend fun forgetLatestMemory(): MemoryEntity? {
        val latest = dao.getLatestActiveMemory() ?: return null
        dao.deleteMemory(latest.id)
        return latest
    }

    suspend fun forgetMemoryMatching(topic: String): Boolean {
        val matches = dao.searchMemories(topic)
        if (matches.isNotEmpty()) {
            for (match in matches) {
                dao.deleteMemory(match.id)
            }
            return true
        }
        return false
    }

    /**
     * Resolves contact aliases based on stored relationship memories.
     * E.g. "Dad is saved as Papa in my contacts" -> query "Dad" returns ["Dad", "Papa"].
     */
    suspend fun resolveContactAliases(contactQuery: String): List<String> {
        val candidates = mutableListOf(contactQuery)
        val cleanQuery = contactQuery.lowercase().trim()
        val memories = dao.getActiveMemoriesSnapshot()
        
        for (m in memories) {
            val lower = m.content.lowercase()
            // Check patterns like: "Dad is saved as Papa", "Papa is Dad", "call Papa means Dad"
            if (lower.contains(cleanQuery)) {
                // Extract possible name words
                val regexSavedAs = Regex("""([a-zA-Z]+)\s+is\s+saved\s+as\s+([a-zA-Z]+)""", RegexOption.IGNORE_CASE)
                val match = regexSavedAs.find(m.content)
                if (match != null) {
                    val p1 = match.groupValues[1]
                    val p2 = match.groupValues[2]
                    if (p1.equals(cleanQuery, ignoreCase = true)) candidates.add(p2)
                    if (p2.equals(cleanQuery, ignoreCase = true)) candidates.add(p1)
                }
                val regexMeans = Regex("""([a-zA-Z]+)\s+means\s+([a-zA-Z]+)""", RegexOption.IGNORE_CASE)
                val matchMeans = regexMeans.find(m.content)
                if (matchMeans != null) {
                    val p1 = matchMeans.groupValues[1]
                    val p2 = matchMeans.groupValues[2]
                    if (p1.equals(cleanQuery, ignoreCase = true)) candidates.add(p2)
                    if (p2.equals(cleanQuery, ignoreCase = true)) candidates.add(p1)
                }
                val regexIs = Regex("""([a-zA-Z]+)\s+is\s+([a-zA-Z]+)""", RegexOption.IGNORE_CASE)
                val matchIs = regexIs.find(m.content)
                if (matchIs != null) {
                    val p1 = matchIs.groupValues[1]
                    val p2 = matchIs.groupValues[2]
                    if (p1.equals(cleanQuery, ignoreCase = true)) candidates.add(p2)
                    if (p2.equals(cleanQuery, ignoreCase = true)) candidates.add(p1)
                }
            }
        }
        return candidates.distinct()
    }

    suspend fun toggleMemory(id: Long, isActive: Boolean) {
        dao.toggleMemoryActive(id, isActive)
    }

    suspend fun logTranscript(role: String, content: String, latencyMs: Long? = null): Long {
        return dao.insertTranscript(
            TranscriptEntity(
                role = role,
                content = content,
                latencyMs = latencyMs
            )
        )
    }

    suspend fun clearHistory() {
        dao.clearTranscripts()
    }
}
