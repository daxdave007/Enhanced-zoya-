package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ZoyaDao {

    // --- Memory & Personalization Queries ---

    @Query("SELECT * FROM memories ORDER BY createdAt DESC")
    fun getAllMemories(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories WHERE isActive = 1 ORDER BY createdAt DESC")
    fun getActiveMemories(): Flow<List<MemoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: MemoryEntity): Long

    @Update
    suspend fun updateMemory(memory: MemoryEntity)

    @Query("SELECT * FROM memories WHERE isActive = 1 ORDER BY createdAt DESC LIMIT 1")
    suspend fun getLatestActiveMemory(): MemoryEntity?

    @Query("SELECT * FROM memories WHERE isActive = 1")
    suspend fun getActiveMemoriesSnapshot(): List<MemoryEntity>

    @Query("SELECT * FROM memories WHERE isActive = 1 AND (content LIKE '%' || :keyword || '%' OR category LIKE '%' || :keyword || '%') ORDER BY createdAt DESC")
    suspend fun searchMemories(keyword: String): List<MemoryEntity>

    @Query("DELETE FROM memories WHERE id = :id")
    suspend fun deleteMemory(id: Long)

    @Query("UPDATE memories SET isActive = :isActive WHERE id = :id")
    suspend fun toggleMemoryActive(id: Long, isActive: Boolean)

    // --- Transcript & History Queries ---

    @Query("SELECT * FROM transcripts ORDER BY timestamp DESC")
    fun getAllTranscripts(): Flow<List<TranscriptEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTranscript(transcript: TranscriptEntity): Long

    @Query("DELETE FROM transcripts")
    suspend fun clearTranscripts()
}
