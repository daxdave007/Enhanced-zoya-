package com.example.live

sealed class PendingAction {
    data class Call(
        val contactName: String,
        val phoneNumber: String,
        val simSlot: Int? = null
    ) : PendingAction()

    data class SendWhatsApp(
        val contactName: String,
        val message: String
    ) : PendingAction()

    data class DeleteMemory(
        val memoryId: Long,
        val description: String
    ) : PendingAction()
}
