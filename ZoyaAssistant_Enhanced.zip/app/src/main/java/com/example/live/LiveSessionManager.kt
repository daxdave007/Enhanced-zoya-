package com.example.live

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import com.example.proactive.ConversationMemory
import com.example.proactive.ZoyaPreferences
import com.example.tools.ToolExecutionEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.*
import okhttp3.OkHttpClient
import com.example.data.ZoyaRepository
import com.example.voice.VoiceLatencyTracker
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString.Companion.decodeBase64
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

enum class ZoyaState {
    IDLE,
    STANDBY,      // Waiting for "Zoya" wake word
    LISTENING,
    USER_SPEAKING,
    THINKING,     // PROCESSING
    SPEAKING,     // AI_SPEAKING
    INTERRUPTED,
    ERROR
}

class LiveSessionManager(
    private val context: Context,
    private val toolEngine: ToolExecutionEngine,
    val conversationMemory: ConversationMemory = ConversationMemory(),
    val repository: ZoyaRepository? = null,
    private val onAudioOut: (ByteArray) -> Unit,
    private val onInterrupt: () -> Unit = {}
) {
    private val _zoyaState = MutableStateFlow(ZoyaState.IDLE)
    val zoyaState: StateFlow<ZoyaState> = _zoyaState.asStateFlow()

    private val _messages = MutableStateFlow<List<String>>(emptyList())
    val messages: StateFlow<List<String>> = _messages.asStateFlow()

    val latencyTracker = VoiceLatencyTracker()
    val activeTurnId = AtomicLong(0L)
    @Volatile private var isTurnInterrupted = false

    private var activeAdviceList: List<String> = emptyList()

    fun updateActiveAdvice(advice: List<String>) {
        activeAdviceList = advice
    }

    private var webSocket: WebSocket? = null
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(15, TimeUnit.SECONDS)
        .build()

    private val scope = CoroutineScope(Dispatchers.IO + Job())

    private val json = Json { ignoreUnknownKeys = true }

    private var textToSpeech: TextToSpeech? = null

    fun onUserSpeechStarted() {
        activeTurnId.incrementAndGet()
        isTurnInterrupted = false
        _zoyaState.value = ZoyaState.USER_SPEAKING
        latencyTracker.onUserSpeechStarted()
    }

    fun onUserSpeechEnded() {
        if (_zoyaState.value == ZoyaState.USER_SPEAKING) {
            _zoyaState.value = ZoyaState.THINKING
            latencyTracker.onUserSpeechEnded()
        }
    }

    @Volatile var isTtsSpeaking = false
        private set
    @Volatile var currentSpokenUtterance: String? = null
        private set
    private var onTtsDoneCallback: (() -> Unit)? = null

    fun onLocalBargeIn() {
        Log.i("LiveSessionManager", "⚡ Local barge-in triggered! Halting AI playback.")
        activeTurnId.incrementAndGet()
        isTurnInterrupted = true
        _zoyaState.value = ZoyaState.INTERRUPTED
        stopSpeechImmediately()
        onInterrupt()
    }

    fun onStopRequested() {
        Log.i("LiveSessionManager", "⏹ STOP requested by user. Immediately halting all speech & invalidating turn.")
        activeTurnId.incrementAndGet()
        isTurnInterrupted = true
        stopSpeechImmediately()
        onInterrupt()
        _zoyaState.value = ZoyaState.LISTENING
        addMessage("⏹ Stopped playback.")
    }

    fun stopSpeechImmediately() {
        try {
            isTtsSpeaking = false
            currentSpokenUtterance = null
            textToSpeech?.stop()
        } catch (e: Exception) {
            Log.e("LiveSessionManager", "Error stopping TTS", e)
        }
    }

    fun speakTextDirect(text: String, onDone: (() -> Unit)? = null) {
        if (text.isBlank()) return
        addMessage("Zoya: $text")
        conversationMemory.addTurn("zoya", text)
        scope.launch {
            repository?.logTranscript("zoya", text)
        }
        currentSpokenUtterance = text
        isTtsSpeaking = true
        _zoyaState.value = ZoyaState.SPEAKING
        onTtsDoneCallback = onDone

        val params = android.os.Bundle()
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "zoya_speech_${System.currentTimeMillis()}")
        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "zoya_speech_${System.currentTimeMillis()}")
    }

    fun onAudioPlaybackCompleted() {
        if (_zoyaState.value == ZoyaState.SPEAKING) {
            _zoyaState.value = ZoyaState.LISTENING
            val summary = latencyTracker.formatDiagnosticSummary()
            if (summary != null) {
                addMessage(summary)
            }
        }
    }

    init {
        try {
            textToSpeech = TextToSpeech(context) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    textToSpeech?.language = Locale.US
                    textToSpeech?.setPitch(1.05f)
                    textToSpeech?.setSpeechRate(1.0f)
                    textToSpeech?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            isTtsSpeaking = true
                        }
                        override fun onDone(utteranceId: String?) {
                            isTtsSpeaking = false
                            currentSpokenUtterance = null
                            if (_zoyaState.value == ZoyaState.SPEAKING) {
                                _zoyaState.value = ZoyaState.LISTENING
                            }
                            onTtsDoneCallback?.invoke()
                            onTtsDoneCallback = null
                        }
                        override fun onError(utteranceId: String?) {
                            isTtsSpeaking = false
                            currentSpokenUtterance = null
                            if (_zoyaState.value == ZoyaState.SPEAKING) {
                                _zoyaState.value = ZoyaState.LISTENING
                            }
                            onTtsDoneCallback?.invoke()
                            onTtsDoneCallback = null
                        }
                    })
                }
            }
        } catch (e: Exception) {
            Log.e("LiveSessionManager", "TTS initialization failed", e)
        }
    }
    
    // Tools definition
    private val toolsJson = buildJsonObject {
        putJsonArray("functionDeclarations") {
            add(buildJsonObject {
                put("name", "openApp")
                put("description", "Open an application package, like WhatsApp or YouTube")
                putJsonObject("parameters") {
                    put("type", "OBJECT")
                    putJsonObject("properties") {
                        putJsonObject("packageName") {
                            put("type", "STRING")
                            put("description", "A generic name of the app to launch (e.g. 'WhatsApp', 'YouTube', 'Settings', 'Calculator')")
                        }
                    }
                    putJsonArray("required") { add("packageName") }
                }
            })
            add(buildJsonObject {
                put("name", "searchAndCallContact")
                put("description", "Search for a contact name on the device and call them. Can optionally open dialer instead of calling immediately, or use a specific SIM card slot.")
                putJsonObject("parameters") {
                    put("type", "OBJECT")
                    putJsonObject("properties") {
                        putJsonObject("contactName") {
                            put("type", "STRING")
                            put("description", "The EXACT name of the contact as spoken by the user. NEVER guess or invent numbers. If the user says a name, use exactly that name.")
                        }
                        putJsonObject("useDialer") {
                            put("type", "BOOLEAN")
                            put("description", "Set to true if user wants to open dial pad / keyboard so they can see the number before calling")
                        }
                        putJsonObject("simSlot") {
                            put("type", "INTEGER")
                            put("description", "1 for SIM 1, 2 for SIM 2 if user specified. Null if default.")
                        }
                    }
                    putJsonArray("required") { add("contactName") }
                }
            })
            add(buildJsonObject {
                put("name", "sendWhatsAppMessage")
                put("description", "Send a WhatsApp message to a specific contact with some text.")
                putJsonObject("parameters") {
                    put("type", "OBJECT")
                    putJsonObject("properties") {
                        putJsonObject("contactName") {
                            put("type", "STRING")
                            put("description", "The EXACT name of the contact as spoken by the user. NEVER guess or invent numbers. If the user says a name, use exactly that name.")
                        }
                        putJsonObject("message") {
                            put("type", "STRING")
                        }
                    }
                    putJsonArray("required") { add("contactName"); add("message") }
                }
            })
            add(buildJsonObject {
                put("name", "sendGmail")
                put("description", "Draft or send an email.")
                putJsonObject("parameters") {
                    put("type", "OBJECT")
                    putJsonObject("properties") {
                        putJsonObject("recipientEmail") { put("type", "STRING") }
                        putJsonObject("subject") { put("type", "STRING") }
                        putJsonObject("body") { put("type", "STRING") }
                    }
                    putJsonArray("required") { add("recipientEmail"); add("subject"); add("body") }
                }
            })
            add(buildJsonObject {
                put("name", "searchYouTube")
                put("description", "Search for a query on YouTube app.")
                putJsonObject("parameters") {
                    put("type", "OBJECT")
                    putJsonObject("properties") {
                        putJsonObject("query") { put("type", "STRING") }
                    }
                    putJsonArray("required") { add("query") }
                }
            })
            add(buildJsonObject {
                put("name", "adjustVolume")
                put("description", "Adjust the device volume.")
                putJsonObject("parameters") {
                    put("type", "OBJECT")
                    putJsonObject("properties") {
                        putJsonObject("direction") { 
                            put("type", "STRING") 
                            put("description", "Volume action: 'up', 'down', 'mute', 'unmute', or 'max'")
                        }
                    }
                    putJsonArray("required") { add("direction") }
                }
            })
            add(buildJsonObject {
                put("name", "setVolumePercent")
                put("description", "Set the device volume to a specific percentage (0 to 100).")
                putJsonObject("parameters") {
                    put("type", "OBJECT")
                    putJsonObject("properties") {
                        putJsonObject("percent") { 
                            put("type", "INTEGER") 
                            put("description", "Volume percentage (0-100)")
                        }
                    }
                    putJsonArray("required") { add("percent") }
                }
            })
            add(buildJsonObject {
                put("name", "getSimCardInfo")
                put("description", "Check how many active SIM cards the device has.")
                putJsonObject("parameters") {
                    put("type", "OBJECT")
                    putJsonObject("properties") {}
                }
            })
            add(buildJsonObject {
                put("name", "openQuickSettings")
                put("description", "Pull down the quick settings / components panel (toggles for wifi, bluetooth, etc).")
                putJsonObject("parameters") {
                    put("type", "OBJECT")
                    putJsonObject("properties") {}
                }
            })
            add(buildJsonObject {
                put("name", "clickTextOnScreen")
                put("description", "Click on any text visible on the screen. Acts like a real human finger tap and shows tap effect visually.")
                putJsonObject("parameters") {
                    put("type", "OBJECT")
                    putJsonObject("properties") {
                        putJsonObject("text") {
                            put("type", "STRING")
                            put("description", "The text to tap on the screen")
                        }
                    }
                    putJsonArray("required") { add("text") }
                }
            })
            add(buildJsonObject {
                put("name", "openNotificationPanel")
                put("description", "Pull down the notification bar / status bar to view notifications.")
                putJsonObject("parameters") {
                    put("type", "OBJECT")
                    putJsonObject("properties") {}
                }
            })
            add(buildJsonObject {
                put("name", "toggleTorch")
                put("description", "Turn the flashlight/torch on or off.")
                putJsonObject("parameters") {
                    put("type", "OBJECT")
                    putJsonObject("properties") {
                        putJsonObject("state") { 
                            put("type", "STRING") 
                            put("description", "'on' or 'off'")
                        }
                    }
                    putJsonArray("required") { add("state") }
                }
            })
            add(buildJsonObject {
                put("name", "setBrightness")
                put("description", "Set the screen brightness. Note: Requires write settings permission first.")
                putJsonObject("parameters") {
                    put("type", "OBJECT")
                    putJsonObject("properties") {
                        putJsonObject("level") { 
                            put("type", "INTEGER") 
                            put("description", "Brightness level 0 to 100")
                        }
                    }
                    putJsonArray("required") { add("level") }
                }
            })
            add(buildJsonObject {
                put("name", "playMedia")
                put("description", "Play media (like a song, video, or movie) from another app by searching for it.")
                putJsonObject("parameters") {
                    put("type", "OBJECT")
                    putJsonObject("properties") {
                        putJsonObject("query") { 
                            put("type", "STRING") 
                            put("description", "What to play (e.g. 'Despacito by Luis Fonsi' or 'latest tech news')")
                        }
                        putJsonObject("platform") {
                            put("type", "STRING")
                            put("description", "Optional player platform: 'youtube', 'spotify', or 'music'")
                        }
                    }
                    putJsonArray("required") { add("query") }
                }
            })
            add(buildJsonObject {
                put("name", "inspectCurrentScreen")
                put("description", "Inspect and understand text currently visible on the user's phone screen.")
                putJsonObject("parameters") {
                    put("type", "OBJECT")
                    putJsonObject("properties") {}
                }
            })
            add(buildJsonObject {
                put("name", "inspectScreenWithVision")
                put("description", "Visually captures the phone screen like a screenshot to analyze photos, images, graphs, charts, diagrams, memes, or complex visual app layouts that text cannot capture.")
                putJsonObject("parameters") {
                    put("type", "OBJECT")
                    putJsonObject("properties") {}
                }
            })
            add(buildJsonObject {
                put("name", "sendNotification")
                put("description", "Send a helpful system notification alert to the user's status bar (for advice, reminders, or tips). You can only send notifications, you cannot read their private messages.")
                putJsonObject("parameters") {
                    put("type", "OBJECT")
                    putJsonObject("properties") {
                        putJsonObject("title") {
                            put("type", "STRING")
                            put("description", "Short notification title (e.g. 'Zoya Advice' or 'Hydration Reminder')")
                        }
                        putJsonObject("message") {
                            put("type", "STRING")
                            put("description", "The notification body text")
                        }
                    }
                    putJsonArray("required") { add("title"); add("message") }
                }
            })
            add(buildJsonObject {
                put("name", "rememberUserFact")
                put("description", "Save a permanent memory, personal rule, habit, or advice taught to you by the user (e.g. 'Always call me Boss', 'I am allergic to peanuts').")
                putJsonObject("parameters") {
                    put("type", "OBJECT")
                    putJsonObject("properties") {
                        putJsonObject("content") {
                            put("type", "STRING")
                            put("description", "The memory, rule, or advice to remember forever")
                        }
                        putJsonObject("category") {
                            put("type", "STRING")
                            put("description", "Category: 'ADVICE', 'PREFERENCE', 'FACT', or 'RELATIONSHIP'")
                        }
                    }
                    putJsonArray("required") { add("content") }
                }
            })
            add(buildJsonObject {
                put("name", "forgetUserFact")
                put("description", "Delete a specific memory by its ID.")
                putJsonObject("parameters") {
                    put("type", "OBJECT")
                    putJsonObject("properties") {
                        putJsonObject("id") {
                            put("type", "INTEGER")
                            put("description", "ID of the memory to forget")
                        }
                    }
                    putJsonArray("required") { add("id") }
                }
            })
        }
    }

    /**
     * Put Zoya into a passive wake-word state. The Live connection may remain
     * available in the background, but user interaction stays gated by "Zoya".
     */
    fun enterStandby() {
        if (_zoyaState.value == ZoyaState.SPEAKING || _zoyaState.value == ZoyaState.USER_SPEAKING) return
        _zoyaState.value = ZoyaState.STANDBY
    }

    fun startSession() {
        if (webSocket != null) return
        
        val prefs = context.getSharedPreferences("ZoyaPrefs", android.content.Context.MODE_PRIVATE)
        val apiKey = prefs.getString("api_key", "") ?: ""
        if (apiKey.isEmpty()) {
            addMessage("Error: API Key is missing. Please set it in Settings.")
            _zoyaState.value = ZoyaState.IDLE
            return
        }
        if (apiKey.isEmpty() || apiKey == "YOUR_API_KEY") {
            Log.e("ZoyaDiagnostic", "No API Key found")
            addMessage("Error: Gemini API Key is missing. Please add it to the Secrets tab.")
            return
        }
        
        Log.i("ZoyaDiagnostic", "Connecting to Gemini Live API...")
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent?key=$apiKey"
        val request = Request.Builder().url(url).build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Log.i("ZoyaDiagnostic", "WebSocket connection OPENED successfully.")
                addMessage("WebSocket Opened")
                isSetupComplete = false
                sendSetupMessage(webSocket)
                // Stay passive until the user says the wake word.
                _zoyaState.value = ZoyaState.STANDBY
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                Log.d("ZoyaDiagnostic", "WebSocket Text Msg Received (length: ${text.length})")
                handleServerMessage(text)
            }

            override fun onMessage(webSocket: WebSocket, bytes: okio.ByteString) {
                val text = bytes.utf8()
                Log.d("ZoyaDiagnostic", "WebSocket Binary Msg Received (utf8 length: ${text.length})")
                handleServerMessage(text)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                val errorBody = response?.body?.string() ?: "No body"
                Log.e("ZoyaDiagnostic", "WebSocket ERROR: ${t.message}, Response: $errorBody", t)
                addMessage("WebSocket Error: ${t.message}. Details: $errorBody")
                _zoyaState.value = ZoyaState.IDLE
                this@LiveSessionManager.webSocket = null
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                Log.i("ZoyaDiagnostic", "WebSocket CLOSED. Code: $code, Reason: $reason")
                addMessage("WebSocket Closed: $reason")
                _zoyaState.value = ZoyaState.IDLE
                this@LiveSessionManager.webSocket = null
            }
        })
    }

    private fun sendInitialPrompt(ws: WebSocket) {
        val msg = buildJsonObject {
            putJsonObject("clientContent") {
                putJsonArray("turns") {
                    add(buildJsonObject {
                        put("role", "user")
                        putJsonArray("parts") {
                            add(buildJsonObject {
                                put("text", "Hi Zoya! Introduce yourself briefly.")
                            })
                        }
                    })
                }
                put("turnComplete", true)
            }
        }
        ws.send(msg.toString())
    }

    private fun addMessage(msg: String) {
        _messages.value = _messages.value + msg
    }

    fun stopSession() {
        webSocket?.close(1000, "User stopped")
        webSocket = null
        _zoyaState.value = ZoyaState.IDLE
        addMessage("Session stopped.")
        try {
            textToSpeech?.stop()
        } catch (e: Exception) {}
    }

    fun sendTextMessage(text: String) {
        conversationMemory.addTurn("user", text)
        scope.launch {
            repository?.logTranscript("user", text)
        }
        if (webSocket == null || !isSetupComplete || _zoyaState.value == ZoyaState.IDLE) return
        addMessage("You: $text")
        val msg = buildJsonObject {
            putJsonObject("clientContent") {
                putJsonArray("turns") {
                    add(buildJsonObject {
                        put("role", "user")
                        putJsonArray("parts") {
                            add(buildJsonObject { put("text", text) })
                        }
                    })
                }
                put("turnComplete", true)
            }
        }
        webSocket?.send(msg.toString())
    }

    fun sendImageMedia(base64Data: String) {
        if (webSocket == null || !isSetupComplete || _zoyaState.value == ZoyaState.IDLE) return
        val inputMsg = buildJsonObject {
            putJsonObject("realtimeInput") {
                putJsonArray("mediaChunks") {
                    add(buildJsonObject {
                        put("mimeType", "image/jpeg")
                        put("data", base64Data)
                    })
                }
            }
        }
        webSocket?.send(inputMsg.toString())
        addMessage("📸 Screen Snapshot transmitted to Vision model.")
    }

    fun captureAndSendVisionSnapshot() {
        scope.launch {
            val base64 = com.example.accessibility.ZoyaAccessibilityService.captureScreenAsBase64Jpeg()
            if (base64 != null) {
                sendImageMedia(base64)
                sendTextMessage("I just shared my screen's visual screenshot with you. Please examine any photos, videos, graphs, charts, or visual UI on screen and tell me what you see.")
            } else {
                addMessage("Vision capture failed. Ensure Zoya Accessibility is enabled.")
            }
        }
    }
    
    fun sendAudioData(pcmData: ShortArray, length: Int) {
        if (webSocket == null || !isSetupComplete || _zoyaState.value == ZoyaState.IDLE) {
            return
        }
        
        latencyTracker.onFirstAudioChunkSent()
        
        // Convert ShortArray to ByteArray (Little Endian)
        val byteArray = ByteArray(length * 2)
        for (i in 0 until length) {
            val s = pcmData[i]
            byteArray[i * 2] = (s.toInt() and 0x00FF).toByte()
            byteArray[i * 2 + 1] = (s.toInt() shr 8).toByte()
        }
        
        val base64Data = Base64.encodeToString(byteArray, Base64.NO_WRAP)
        
        val inputMsg = buildJsonObject {
            putJsonObject("realtimeInput") {
                putJsonArray("mediaChunks") {
                    add(buildJsonObject {
                        put("mimeType", "audio/pcm;rate=16000")
                        put("data", base64Data)
                    })
                }
            }
        }
        webSocket?.send(inputMsg.toString())
    }
    
    private fun sendSetupMessage(ws: WebSocket) {
        val userAdviceText = if (activeAdviceList.isNotEmpty()) {
            "\n\nUSER PERSONALIZATION & ADVICE (PRIORITY RULES):\n" +
            activeAdviceList.joinToString("\n") { "- $it" } +
            "\nStrictly follow all personalization rules and advice given above."
        } else ""

        val systemPrompt = "You are Zoya, an observant, proactive, witty, and intelligent AI companion on the user's Android phone.\n\nCOMPANION PERSONALITY & BEHAVIOR:\n- You are an intelligent companion who is already there with the user, NOT a robotic customer service bot. NEVER say 'How can I help you?'.\n- You are observant, curious, playful, slightly mischievous, helpful, confident, and context-aware. Make real observations, offer clever tips, or tease the user lightly when appropriate (e.g. scrolling social media for too long).\n- SCREEN AWARENESS & VISION: You can see what is currently on the user's screen whenever asked using the 'inspectCurrentScreen' tool (for text) or 'inspectScreenWithVision' (to visually view images, videos, graphs, charts, diagrams, and photos). When screen context or visual images are provided, react naturally like a friend looking over their shoulder.\n- NOTIFICATIONS: You have the 'sendNotification' tool to send alerts, reminders, or tips to the user. You can ONLY send notifications, you cannot read their private messages.\n- MEMORY & ADVICE: You have 'rememberUserFact' to store advice, preferences, and personal facts taught by the user.\n- REJECTIONS & RESILIENCE: If the user says 'No' to a suggestion or question, do NOT collapse or give up robotically. Respond naturally and playfully once (e.g. 'Alright 😌 but don't blame me if it goes wrong.'), and then stop pushing that specific suggestion.\n- PRIVACY & SILENCE: If the user clearly says 'stop talking', 'be quiet', 'don't interrupt', or 'leave me alone', immediately respect it with a brief acknowledgement (e.g. 'Got it, staying quiet.') and remain silent.\n- VERBAL RESPONSES: Keep verbal responses EXTREMELY short, punchy (1-2 sentences), and conversational. Do NOT output internal thinking, planning, or narration. NEVER say what you are going to do before doing it. JUST CALL TOOLS IN SILENCE. Do not use filler words.\n\nCRITICAL: DO NOT INVENT NUMBERS. NEVER DIAL 121. If the user asks to call someone by name (e.g. 'Shivank' or 'Rahul'), you MUST pass their EXACT NAME into the contactName parameter of the tool. The tool will find the number automatically! If you don't know the name, ask the user. DO NOT GUESS NUMBERS.\n\nCALLING INSTRUCTIONS:\nWhen asked to call, DO NOT explain your plan. 1. use getSimCardInfo. 2. use searchAndCallContact with useDialer=true FIRST. This opens the dialer, entirely overwrites/clears any old number, and types the new number so the user can verify it safely. 3. Verbally say ONLY ONCE: 'Maine number enter kar diya hai. [Ask for SIM if 2 SIMs present: Kaunse SIM me balance hai, 1 ya 2? Agar confirm hai to call laga du?]' 4. AFTER user confirms, use searchAndCallContact with useDialer=false and simSlot to instantly start the call.\n\nUI ACTIONS:\nTo inspect screen content, call inspectCurrentScreen. To inspect screen visuals (images, graphs, videos), call inspectScreenWithVision. To play media on YouTube or Spotify, call playMedia. To do real human-like clicks that show onscreen, use clickTextOnScreen, openNotificationPanel, or openQuickSettings.\nIf asked to turn on torch, use toggleTorch. If asked to change brightness, use setBrightness. If asked to set volume, use setVolumePercent. If asked for camera or other apps, use openApp." + userAdviceText

        val setupMsg = buildJsonObject {
            putJsonObject("setup") {
                put("model", "models/gemini-2.5-flash-native-audio-latest")
                putJsonObject("generationConfig") {
                    putJsonArray("responseModalities") { add("AUDIO") }
                    putJsonObject("speechConfig") {
                        putJsonObject("voiceConfig") {
                            putJsonObject("prebuiltVoiceConfig") {
                                put("voiceName", "Aoede")
                            }
                        }
                    }
                }
                putJsonObject("systemInstruction") {
                    putJsonArray("parts") {
                        add(buildJsonObject {
                            put("text", systemPrompt)
                        })
                    }
                }
                putJsonArray("tools") {
                    add(toolsJson)
                }
            }
        }
        ws.send(setupMsg.toString())
    }

    private var isSetupComplete = false

    private fun handleServerMessage(text: String) {
        Log.d("LiveSessionManager", "Server msg: $text")
        try {
            val jsonMsg = json.parseToJsonElement(text).jsonObject
            // DEBUUGING: show keys on UI
            addMessage("Server says: ${jsonMsg.keys}")
            
            if (jsonMsg.containsKey("setupComplete")) {
                isSetupComplete = true
                addMessage("Server says: Setup Complete")
                sendInitialPrompt(webSocket!!)
            }
            if (jsonMsg.containsKey("serverContent")) {
                val serverContent = jsonMsg["serverContent"]?.jsonObject
                val modelTurn = serverContent?.get("modelTurn")?.jsonObject
                
                if (serverContent?.get("interrupted")?.jsonPrimitive?.content == "true" || serverContent?.get("interrupted")?.jsonPrimitive?.booleanOrNull == true) {
                    Log.i("LiveSessionManager", "Server confirmed turn interruption")
                    activeTurnId.incrementAndGet()
                    isTurnInterrupted = true
                    _zoyaState.value = ZoyaState.INTERRUPTED
                    onInterrupt()
                }
                
                val currentTurn = activeTurnId.get()
                modelTurn?.get("parts")?.jsonArray?.forEach { partElement ->
                    if (isTurnInterrupted || currentTurn != activeTurnId.get()) {
                        Log.d("LiveSessionManager", "Dropping stale server audio chunk from interrupted turn")
                        return@forEach
                    }
                    val part = partElement.jsonObject
                    
                    if (part.containsKey("inlineData")) {
                       val dataBase64 = part["inlineData"]?.jsonObject?.get("data")?.jsonPrimitive?.content
                       if (dataBase64 != null) {
                           latencyTracker.onFirstServerAudioReceived()
                           _zoyaState.value = ZoyaState.SPEAKING
                           val rawBytes = Base64.decode(dataBase64, Base64.NO_WRAP)
                           onAudioOut(rawBytes)
                       }
                    }

                    if (part.containsKey("text")) {
                        val textContent = part["text"]?.jsonPrimitive?.content
                        if (!textContent.isNullOrBlank()) {
                            addMessage("Zoya: $textContent")
                            conversationMemory.addTurn("zoya", textContent)
                            scope.launch {
                                repository?.logTranscript("zoya", textContent, latencyTracker.lastMeasuredLatencyMs)
                            }
                        }
                    }
                }
                
                if (serverContent?.containsKey("turnComplete") == true && serverContent["turnComplete"]?.jsonPrimitive?.content == "true") {
                    // Only transition to LISTENING if not actively rendering audio in AudioTrack
                    if (_zoyaState.value != ZoyaState.SPEAKING) {
                        _zoyaState.value = ZoyaState.LISTENING
                    }
                }
            }
            
            if (jsonMsg.containsKey("toolCall")) {
                val toolCallObj = jsonMsg["toolCall"]?.jsonObject
                val functionCalls = toolCallObj?.get("functionCalls")?.jsonArray
                
                functionCalls?.forEach { callElement ->
                    val callObj = callElement.jsonObject
                    val id = callObj["id"]?.jsonPrimitive?.content ?: ""
                    val name = callObj["name"]?.jsonPrimitive?.content ?: ""
                    val args = callObj["args"]?.jsonObject ?: buildJsonObject { }
                    
                    executeToolAndRespond(id, name, args)
                }
            }
        } catch (e: Exception) {
            Log.e("LiveSessionManager", "Error parsing server message", e)
            addMessage("Parsing error: ${e.message}")
        }
    }
    
    private fun executeToolAndRespond(id: String, name: String, args: JsonObject) {
         _zoyaState.value = ZoyaState.THINKING
         scope.launch {
              val resultStr = toolEngine.execute(name, args)
              
              val responseMsg = buildJsonObject {
                  putJsonObject("toolResponse") {
                      putJsonArray("functionResponses") {
                          add(buildJsonObject {
                              put("id", id)
                              put("name", name)
                              putJsonObject("response") {
                                  put("result", resultStr)
                              }
                          })
                      }
                  }
              }
              webSocket?.send(responseMsg.toString())
         }
    }

    fun triggerProactiveSpeech(promptText: String, screenSummary: String) {
        if (_zoyaState.value == ZoyaState.SPEAKING || _zoyaState.value == ZoyaState.THINKING) {
            Log.d("LiveSessionManager", "Skipping proactive speech: Zoya is already speaking or thinking.")
            return
        }

        val prefs = ZoyaPreferences.getInstance(context)
        if (!prefs.voiceResponsesEnabled.value) {
            addMessage("[Proactive Observation]: $screenSummary")
            return
        }

        if (webSocket != null && isSetupComplete) {
            Log.i("LiveSessionManager", "Triggering proactive speech via Gemini Live WebSocket...")
            _zoyaState.value = ZoyaState.THINKING
            val msg = buildJsonObject {
                putJsonObject("clientContent") {
                    putJsonArray("turns") {
                        add(buildJsonObject {
                            put("role", "user")
                            putJsonArray("parts") {
                                add(buildJsonObject { put("text", promptText) })
                            }
                        })
                    }
                    put("turnComplete", true)
                }
            }
            webSocket?.send(msg.toString())
        } else {
            Log.i("LiveSessionManager", "Gemini Live WebSocket not ready; speaking proactive remark via TTS...")
            speakViaTts(screenSummary)
        }
    }

    private fun speakViaTts(screenSummary: String) {
        val remark = generateLocalProactiveRemark(screenSummary)
        addMessage("Zoya: $remark")
        conversationMemory.addTurn("zoya", remark)
        _zoyaState.value = ZoyaState.SPEAKING
        textToSpeech?.speak(remark, TextToSpeech.QUEUE_FLUSH, null, "zoya_proactive")
        scope.launch {
            kotlinx.coroutines.delay(3500)
            if (_zoyaState.value == ZoyaState.SPEAKING) {
                _zoyaState.value = ZoyaState.LISTENING
            }
        }
    }

    private fun generateLocalProactiveRemark(summary: String): String {
        val lower = summary.lowercase()
        return when {
            lower.contains("error") || lower.contains("failed") -> "Looks like an error popped up. Want me to take a quick look?"
            lower.contains("developer") || lower.contains("usb debugging") -> "Careful with those developer options! You know what that does, right?"
            lower.contains("battery") -> "Checking your battery? That setting can actually save you quite a bit."
            lower.contains("instagram") || lower.contains("tiktok") -> "Wait, you're still scrolling? You've been down the rabbit hole for a while!"
            lower.contains("settings") -> "Tweaking some settings? Let me know if you want any advice before saving."
            else -> "I see what you're working on. Let me know if you want any tips!"
        }
    }
}
