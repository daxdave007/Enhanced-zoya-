package com.example.proactive

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ProactiveDecisionEngine(
    private val context: Context,
    private val preferences: ZoyaPreferences,
    private val conversationMemory: ConversationMemory,
    private val cooldownManager: InteractionCooldownManager,
    private val onSpeakRequested: (prompt: String, screenSummary: String) -> Unit
) {
    private val scope = CoroutineScope(Dispatchers.Default)

    fun evaluateEvent(event: ProactiveEvent) {
        scope.launch {
            try {
                processEvent(event)
            } catch (e: Exception) {
                Log.e("ProactiveEngine", "Error processing proactive event", e)
            }
        }
    }

    private fun processEvent(event: ProactiveEvent) {
        // 1. Guard check: User settings
        if (!preferences.proactiveEnabled.value) {
            Log.d("ProactiveEngine", "Proactive AI is disabled in settings.")
            return
        }
        if (!preferences.screenAwarenessEnabled.value) {
            Log.d("ProactiveEngine", "Screen awareness is disabled in settings.")
            return
        }
        if (preferences.quietMode.value || conversationMemory.isQuietModeActive()) {
            Log.d("ProactiveEngine", "Quiet mode is currently active. Staying silent.")
            return
        }

        // 2. Guard check: Screen Privacy & Sensitivity
        val screen = event.screenContext
        if (screen.isSensitive || screen.isPasswordPresent) {
            Log.d("ProactiveEngine", "Screen contains sensitive/password elements. Preserving privacy. Staying silent.")
            return
        }

        // 3. Guard check: Don't comment on Zoya's own settings or blank screens
        if (screen.packageName == context.packageName) {
            Log.d("ProactiveEngine", "Current app is Zoya itself. Staying silent.")
            return
        }

        // 4. Guard check: Anti-spam cooldown
        if (!cooldownManager.canInterrupt(event)) {
            Log.d("ProactiveEngine", "Cooldown manager blocked interruption.")
            return
        }

        // 5. Calculate Score based on decision factors
        val decision = calculateProactiveDecision(event)
        Log.i("ProactiveEngine", "Proactive decision score: ${decision.totalScore}, shouldSpeak: ${decision.shouldSpeak}, reason: ${decision.reason}")

        if (decision.shouldSpeak) {
            cooldownManager.recordInterruption(event)
            conversationMemory.recordProactiveIntervention(screen.appName, "[Proactive on ${screen.appName}]")

            val prompt = buildProactivePrompt(event, decision)
            onSpeakRequested(prompt, screen.toSummaryString())
        }
    }

    data class DecisionResult(
        val totalScore: Int,
        val shouldSpeak: Boolean,
        val reason: String,
        val suggestedTone: String
    )

    private fun calculateProactiveDecision(event: ProactiveEvent): DecisionResult {
        var score = 0
        var reason = ""
        var tone = "helpful"

        val screen = event.screenContext
        val visibleTextCombined = screen.visibleTexts.joinToString(" ").lowercase()
        val appLower = screen.appName.lowercase()
        val pkgLower = screen.packageName.lowercase()

        // Factor 1: Error detected (Urgency & Usefulness)
        if (screen.hasErrors || event.type == ProactiveEventType.ERROR_DETECTED ||
            visibleTextCombined.contains("failed to") ||
            visibleTextCombined.contains("something went wrong") ||
            visibleTextCombined.contains("connection error") ||
            visibleTextCombined.contains("access denied") ||
            visibleTextCombined.contains("error 40") ||
            visibleTextCombined.contains("crash")
        ) {
            score += 55
            reason = "User encountered an error or warning on screen"
            tone = "sympathetic and helpful"
        }

        // Factor 2: Conversation Continuation (Connecting to recent topic discussed)
        val matchesRecentTopic = conversationMemory.hasRecentTopicMatch(screen.visibleTexts + screen.appName)
        if (matchesRecentTopic) {
            score += 35
            reason = "Screen matches a recent conversational topic"
            tone = "observant and excited"
        }

        // Factor 3: Settings & Developer Options (High Advice Opportunity)
        if (screen.category == ScreenCategory.SETTINGS || screen.category == ScreenCategory.DEVELOPER ||
            pkgLower.contains("settings") || visibleTextCombined.contains("developer options") ||
            visibleTextCombined.contains("battery saver") || visibleTextCombined.contains("permissions")
        ) {
            // Check if user rejected advice on this topic before
            if (!conversationMemory.isTopicRejected(screen.appName)) {
                score += 30
                reason = "User is configuring system settings or developer options"
                tone = "clever, slightly teasing or informative"
            }
        }

        // Factor 4: Social media & Video entertainment (Playful teasing / curiosity)
        if (screen.category == ScreenCategory.SOCIAL_MEDIA || pkgLower.contains("instagram") ||
            pkgLower.contains("tiktok") || pkgLower.contains("reddit") || pkgLower.contains("twitter") ||
            pkgLower.contains("youtube")
        ) {
            score += 25
            reason = "User is scrolling social media or browsing entertainment"
            tone = "playful and lightly teasing"
        }

        // Factor 5: Inactivity trigger evaluation (~15 seconds check)
        if (event.type == ProactiveEventType.USER_IDLE) {
            if (screen.hasErrors) {
                score += 35
                reason = "User paused on a screen with an active error or alert"
                tone = "helpful and supportive"
            } else if (screen.category == ScreenCategory.SETTINGS || screen.category == ScreenCategory.DEVELOPER ||
                pkgLower.contains("settings") || visibleTextCombined.contains("developer")
            ) {
                score += 25
                reason = "User spent ~15 seconds on a system setting page"
                tone = "insightful, offering to explain what this option does"
            } else if (screen.category == ScreenCategory.SOCIAL_MEDIA || pkgLower.contains("whatsapp") ||
                pkgLower.contains("youtube") || pkgLower.contains("instagram") || pkgLower.contains("reddit")
            ) {
                score += 25
                reason = "User has been viewing social media or chat"
                tone = "playful and conversational"
            } else if (matchesRecentTopic) {
                score += 20
                reason = "User stayed on a screen related to previous topic"
                tone = "engaged and observant"
            }
        }

        // Factor 6: Curiosity on interesting app opened
        if (event.type == ProactiveEventType.APP_OPENED) {
            score += 15
        }

        // Factor 7: Repetition penalty (check if previously rejected)
        if (conversationMemory.isTopicRejected(screen.appName)) {
            score -= 40
        }

        // Minimum threshold to justify an unsolicited interruption
        val threshold = 45
        val shouldSpeak = score >= threshold

        return DecisionResult(
            totalScore = score,
            shouldSpeak = shouldSpeak,
            reason = if (reason.isEmpty()) "General activity (score: $score)" else reason,
            suggestedTone = tone
        )
    }

    private fun buildProactivePrompt(event: ProactiveEvent, decision: DecisionResult): String {
        val screen = event.screenContext
        val recentTopics = conversationMemory.getActiveTopicSnippet()

        return """
[PROACTIVE COMPANION INSTRUCTION]:
You are Zoya, a smart, observant, witty, and playful companion on the user's phone.
You noticed something on the user's screen and decided to speak up proactively.

Current Screen Information:
- App: ${screen.appName} (${screen.packageName})
- Window / Activity: ${screen.windowTitle}
- Context Snippets: ${screen.visibleTexts.take(6).joinToString(", ")}
- Trigger Reason: ${decision.reason}
- Suggested Tone: ${decision.suggestedTone}
- Recent conversation topics: $recentTopics

CRITICAL RULES:
1. Speak EXACTLY 1 short, lively, natural sentence (under 15 words).
2. DO NOT say "I see on your screen", "As an AI", or "How can I help you?".
3. React naturally like a witty friend looking over their shoulder.
4. If it's an error, give a quick clever tip.
5. If it's settings or developer tools, make an insightful or playful observation.
6. If it's social media, tease playfully (e.g. "Wait 😭 you're still scrolling?").
7. Speak directly to the user in your voice.
""".trimIndent()
    }
}
