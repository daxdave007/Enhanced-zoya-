package com.example.proactive

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ZoyaPreferences(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("ZoyaPrefs", Context.MODE_PRIVATE)

    private val _proactiveEnabled = MutableStateFlow(prefs.getBoolean(KEY_PROACTIVE, true))
    val proactiveEnabled: StateFlow<Boolean> = _proactiveEnabled.asStateFlow()

    private val _screenAwarenessEnabled = MutableStateFlow(prefs.getBoolean(KEY_SCREEN_AWARENESS, true))
    val screenAwarenessEnabled: StateFlow<Boolean> = _screenAwarenessEnabled.asStateFlow()

    private val _voiceResponsesEnabled = MutableStateFlow(prefs.getBoolean(KEY_VOICE_RESPONSES, true))
    val voiceResponsesEnabled: StateFlow<Boolean> = _voiceResponsesEnabled.asStateFlow()

    private val _quietMode = MutableStateFlow(prefs.getBoolean(KEY_QUIET_MODE, false))
    val quietMode: StateFlow<Boolean> = _quietMode.asStateFlow()

    private val _directCallingEnabled = MutableStateFlow(prefs.getBoolean(KEY_DIRECT_CALLING, false))
    val directCallingEnabled: StateFlow<Boolean> = _directCallingEnabled.asStateFlow()

    private val _wakeWordEnabled = MutableStateFlow(prefs.getBoolean(KEY_WAKE_WORD, true))
    val wakeWordEnabled: StateFlow<Boolean> = _wakeWordEnabled.asStateFlow()

    private val _screenObservationModeEnabled = MutableStateFlow(prefs.getBoolean(KEY_SCREEN_OBSERVATION, true))
    val screenObservationModeEnabled: StateFlow<Boolean> = _screenObservationModeEnabled.asStateFlow()

    fun setProactiveEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_PROACTIVE, enabled).apply()
        _proactiveEnabled.value = enabled
    }

    fun setScreenAwarenessEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SCREEN_AWARENESS, enabled).apply()
        _screenAwarenessEnabled.value = enabled
    }

    fun setVoiceResponsesEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_VOICE_RESPONSES, enabled).apply()
        _voiceResponsesEnabled.value = enabled
    }

    fun setQuietMode(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_QUIET_MODE, enabled).apply()
        _quietMode.value = enabled
    }

    fun setDirectCallingEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_DIRECT_CALLING, enabled).apply()
        _directCallingEnabled.value = enabled
    }

    fun setWakeWordEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_WAKE_WORD, enabled).apply()
        _wakeWordEnabled.value = enabled
    }

    fun setScreenObservationModeEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SCREEN_OBSERVATION, enabled).apply()
        _screenObservationModeEnabled.value = enabled
    }

    companion object {
        private const val KEY_PROACTIVE = "proactive_ai_enabled"
        private const val KEY_SCREEN_AWARENESS = "screen_awareness_enabled"
        private const val KEY_VOICE_RESPONSES = "voice_responses_enabled"
        private const val KEY_QUIET_MODE = "quiet_mode_enabled"
        private const val KEY_DIRECT_CALLING = "direct_calling_enabled"
        private const val KEY_WAKE_WORD = "wake_word_enabled"
        private const val KEY_SCREEN_OBSERVATION = "screen_observation_mode_enabled"

        @Volatile
        private var INSTANCE: ZoyaPreferences? = null

        fun getInstance(context: Context): ZoyaPreferences {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: ZoyaPreferences(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
