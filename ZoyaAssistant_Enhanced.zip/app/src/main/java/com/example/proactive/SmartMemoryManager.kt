package com.example.proactive

import android.util.Log
import com.example.data.MemoryEntity
import com.example.data.ZoyaRepository

class SmartMemoryManager(private val repository: ZoyaRepository) {

    companion object {
        private const val TAG = "SmartMemoryManager"

        private val FORGET_PATTERNS = listOf(
            Regex("""^(?:zoya\s*,?\s*)?forget\s+that(?:\s+please)?$""", RegexOption.IGNORE_CASE),
            Regex("""^(?:zoya\s*,?\s*)?forget\s+what\s+i\s+(?:just\s+)?said$""", RegexOption.IGNORE_CASE),
            Regex("""^(?:zoya\s*,?\s*)?forget\s+it$""", RegexOption.IGNORE_CASE),
            Regex("""^(?:zoya\s*,?\s*)?remove\s+that\s+from\s+(?:your\s+)?memory$""", RegexOption.IGNORE_CASE),
            Regex("""^(?:zoya\s*,?\s*)?delete\s+that\s+memory$""", RegexOption.IGNORE_CASE)
        )

        private val FORGET_TOPIC_REGEX = Regex(
            """^(?:zoya\s*,?\s*)?forget\s+(?:about\s+)?(.+)$""",
            RegexOption.IGNORE_CASE
        )

        private val EXPLICIT_REMEMBER_REGEX = Regex(
            """^(?:zoya\s*,?\s*)?(?:please\s+)?remember\s+(?:that\s+)?(.+)$""",
            RegexOption.IGNORE_CASE
        )

        private val PREFERENCE_PATTERNS = listOf(
            Regex("""^(?:i\s+)?(?:prefer|want)\s+(?:zoya\s+)?(?:to\s+)?(.+)$""", RegexOption.IGNORE_CASE),
            Regex("""^(?:always\s+)?(?:call\s+me|refer\s+to\s+me\s+as)\s+(.+)$""", RegexOption.IGNORE_CASE),
            Regex("""^(?:speak|talk|answer)\s+(?:to\s+me\s+)?in\s+(.+)$""", RegexOption.IGNORE_CASE)
        )

        private val RELATIONSHIP_PATTERNS = listOf(
            Regex("""([a-zA-Z]+)\s+is\s+saved\s+as\s+([a-zA-Z]+)(?:\s+in\s+my\s+contacts)?""", RegexOption.IGNORE_CASE),
            Regex("""([a-zA-Z]+)\s+means\s+([a-zA-Z]+)""", RegexOption.IGNORE_CASE),
            Regex("""my\s+([a-zA-Z]+)\s+is\s+([a-zA-Z]+)""", RegexOption.IGNORE_CASE),
            Regex("""call\s+([a-zA-Z]+)\s+means\s+call\s+([a-zA-Z]+)""", RegexOption.IGNORE_CASE)
        )

        // Casual conversation phrases that must NEVER be saved to permanent memory
        private val CASUAL_FILTER_REGEX = Regex(
            """^(?:hi|hello|hey|good\s+morning|good\s+night|how\s+are\s+you|what\s+time|weather|open|call|turn\s+on|turn\s+off|volume|brightness|search|play|stop|cancel|bye).*""",
            RegexOption.IGNORE_CASE
        )
    }

    sealed class MemoryActionResult {
        data class Remembered(val content: String, val category: String) : MemoryActionResult()
        data class Forgotten(val description: String) : MemoryActionResult()
        data class ForgetFailed(val reason: String) : MemoryActionResult()
        object NotAMemoryCommand : MemoryActionResult()
    }

    /**
     * Checks if the utterance is a memory management command ("remember ...", "forget ...")
     * and executes the corresponding Room operation.
     */
    suspend fun processPotentialMemoryUtterance(text: String): MemoryActionResult {
        val trimmed = text.trim()
        val lower = trimmed.lowercase()

        // 1. Check for "forget that" commands
        if (FORGET_PATTERNS.any { it.matches(trimmed) }) {
            val forgotten = repository.forgetLatestMemory()
            return if (forgotten != null) {
                Log.i(TAG, "Forgotten latest memory: ${forgotten.content}")
                MemoryActionResult.Forgotten("I've forgotten: \"${forgotten.content}\"")
            } else {
                MemoryActionResult.ForgetFailed("I don't have any recent memory to forget.")
            }
        }

        // Check for "forget [topic]"
        val forgetTopicMatch = FORGET_TOPIC_REGEX.find(trimmed)
        if (forgetTopicMatch != null) {
            val topic = forgetTopicMatch.groupValues[1].trim()
            if (topic.isNotEmpty() && !topic.equals("that", ignoreCase = true) && !topic.equals("it", ignoreCase = true)) {
                val success = repository.forgetMemoryMatching(topic)
                return if (success) {
                    MemoryActionResult.Forgotten("I've forgotten everything about \"$topic\".")
                } else {
                    MemoryActionResult.ForgetFailed("I couldn't find any memory about \"$topic\".")
                }
            }
        }

        // 2. Check for explicit "remember that..." or "remember..."
        val rememberMatch = EXPLICIT_REMEMBER_REGEX.find(trimmed)
        if (rememberMatch != null) {
            val fact = rememberMatch.groupValues[1].trim()
            if (fact.isNotEmpty() && !CASUAL_FILTER_REGEX.matches(fact)) {
                val category = determineCategory(fact)
                repository.addMemory(fact, category)
                Log.i(TAG, "Explicitly remembered fact: $fact ($category)")
                return MemoryActionResult.Remembered(fact, category)
            }
        }

        // 3. Check for implicit relationship rules: "Dad is saved as Papa in my contacts"
        for (pattern in RELATIONSHIP_PATTERNS) {
            if (pattern.containsMatchIn(trimmed) && !CASUAL_FILTER_REGEX.matches(trimmed)) {
                repository.addMemory(trimmed, "RELATIONSHIP")
                Log.i(TAG, "Detected & saved relationship rule: $trimmed")
                return MemoryActionResult.Remembered(trimmed, "RELATIONSHIP")
            }
        }

        // 4. Check for user preference rules: "I prefer Zoya to answer in Gujarati-English mix"
        for (pattern in PREFERENCE_PATTERNS) {
            if (pattern.containsMatchIn(trimmed) && !CASUAL_FILTER_REGEX.matches(trimmed)) {
                repository.addMemory(trimmed, "PREFERENCE")
                Log.i(TAG, "Detected & saved preference rule: $trimmed")
                return MemoryActionResult.Remembered(trimmed, "PREFERENCE")
            }
        }

        return MemoryActionResult.NotAMemoryCommand
    }

    private fun determineCategory(fact: String): String {
        val lower = fact.lowercase()
        return when {
            RELATIONSHIP_PATTERNS.any { it.containsMatchIn(fact) } ||
            lower.contains("saved as") || lower.contains("contact") || lower.contains("brother") ||
            lower.contains("sister") || lower.contains("father") || lower.contains("mother") ||
            lower.contains("dad") || lower.contains("papa") || lower.contains("mom") || lower.contains("friend") -> "RELATIONSHIP"

            PREFERENCE_PATTERNS.any { it.containsMatchIn(fact) } ||
            lower.contains("prefer") || lower.contains("like to") || lower.contains("language") ||
            lower.contains("english") || lower.contains("gujarati") || lower.contains("hindi") ||
            lower.contains("call me") || lower.contains("tone") -> "PREFERENCE"

            lower.contains("always") || lower.contains("never") || lower.contains("rule") ||
            lower.contains("remind") || lower.contains("everyday") || lower.contains("recurring") -> "ADVICE"

            else -> "FACT"
        }
    }
}
