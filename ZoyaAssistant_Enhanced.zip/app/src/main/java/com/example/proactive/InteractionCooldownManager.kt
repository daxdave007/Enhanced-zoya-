package com.example.proactive

import android.util.Log

class InteractionCooldownManager {

    companion object {
        const val DEFAULT_COOLDOWN_MS = 60_000L // 60 seconds between proactive messages
        const val ERROR_COOLDOWN_MS = 25_000L   // 25 seconds for critical errors
        const val SAME_APP_COOLDOWN_MS = 120_000L // 2 minutes for same app unless major screen change
        const val MAX_INTERRUPTIONS_PER_HOUR = 8
    }

    private var lastInterruptionTimestamp = 0L
    private var lastSpokenScreenHash: String? = null
    private var lastSpokenPackageName: String? = null
    private var lastSpokenAppTimestamp = 0L

    private val hourlyInterruptionTimestamps = mutableListOf<Long>()

    @Synchronized
    fun canInterrupt(
        event: ProactiveEvent,
        forceAllow: Boolean = false
    ): Boolean {
        if (forceAllow) return true

        val now = System.currentTimeMillis()

        // 1. Same-screen repetition prevention
        val screenHash = event.screenContext.contentHash
        if (screenHash.isNotEmpty() && screenHash == lastSpokenScreenHash) {
            Log.d("CooldownManager", "Blocked: Already commented on this exact screen content.")
            return false
        }

        // 2. Minimum interval cooldown
        val minCooldown = if (event.type == ProactiveEventType.ERROR_DETECTED) {
            ERROR_COOLDOWN_MS
        } else {
            DEFAULT_COOLDOWN_MS
        }

        val elapsedSinceLast = now - lastInterruptionTimestamp
        if (elapsedSinceLast < minCooldown) {
            Log.d("CooldownManager", "Blocked by general cooldown: elapsed=${elapsedSinceLast}ms < required=${minCooldown}ms")
            return false
        }

        // 3. Same app cooldown (unless error or different distinct activity)
        if (event.screenContext.packageName == lastSpokenPackageName &&
            event.type != ProactiveEventType.ERROR_DETECTED
        ) {
            val appElapsed = now - lastSpokenAppTimestamp
            if (appElapsed < SAME_APP_COOLDOWN_MS) {
                Log.d("CooldownManager", "Blocked by same-app cooldown: elapsed=${appElapsed}ms < required=${SAME_APP_COOLDOWN_MS}ms")
                return false
            }
        }

        // 4. Hourly fatigue safeguard
        cleanHourlyRecords(now)
        if (hourlyInterruptionTimestamps.size >= MAX_INTERRUPTIONS_PER_HOUR) {
            Log.d("CooldownManager", "Blocked: Exceeded max interruptions per hour (${hourlyInterruptionTimestamps.size}/$MAX_INTERRUPTIONS_PER_HOUR)")
            return false
        }

        return true
    }

    @Synchronized
    fun recordInterruption(event: ProactiveEvent) {
        val now = System.currentTimeMillis()
        lastInterruptionTimestamp = now
        lastSpokenScreenHash = event.screenContext.contentHash
        lastSpokenPackageName = event.screenContext.packageName
        lastSpokenAppTimestamp = now
        hourlyInterruptionTimestamps.add(now)
    }

    @Synchronized
    fun resetCooldown() {
        lastInterruptionTimestamp = 0L
        lastSpokenScreenHash = null
    }

    private fun cleanHourlyRecords(now: Long) {
        val oneHourAgo = now - 3600_000L
        hourlyInterruptionTimestamps.removeAll { it < oneHourAgo }
    }
}
