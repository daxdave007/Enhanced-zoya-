package com.example.proactive

enum class ScreenCategory {
    SETTINGS,
    DEVELOPER,
    SOCIAL_MEDIA,
    BROWSER,
    MEDIA_PLAYER,
    COMMUNICATION,
    SYSTEM_UI,
    ERROR_DIALOG,
    GENERAL
}

data class ScreenContext(
    val packageName: String,
    val appName: String,
    val windowTitle: String,
    val visibleTexts: List<String>,
    val clickableLabels: List<String>,
    val isSensitive: Boolean,
    val isPasswordPresent: Boolean,
    val contentHash: String,
    val timestamp: Long = System.currentTimeMillis(),
    val hasErrors: Boolean = false,
    val category: ScreenCategory = ScreenCategory.GENERAL
) {
    fun toSummaryString(): String {
        if (isSensitive) {
            return "App: $appName (Sensitive Content Protected)"
        }
        val textSnippet = visibleTexts.take(8).joinToString(", ") { "\"$it\"" }
        val buttonsSnippet = if (clickableLabels.isNotEmpty()) {
            " | Actions: " + clickableLabels.take(5).joinToString(", ") { "[$it]" }
        } else ""
        val errorSnippet = if (hasErrors) " [Potential Error/Warning Detected]" else ""
        return "App: $appName ($packageName)${if (windowTitle.isNotBlank()) " - $windowTitle" else ""}$errorSnippet | Content: $textSnippet$buttonsSnippet"
    }

    companion object {
        private val SENSITIVE_PACKAGES = setOf(
            "com.android.settings.password",
            "com.google.android.apps.authenticator2",
            "com.onepassword",
            "com.x8bit.bitwarden",
            "com.lastpass.lpandroid",
            "org.keepassdroid",
            "com.paypal.android.p2pmobile",
            "com.chase.sig.android",
            "com.infonow.bofa",
            "com.wf.wellsfargomobile",
            "com.citi.citimobile",
            "com.capitalonemobile",
            "net.one97.paytm",
            "com.phonepe.app",
            "com.google.android.apps.nbu.paisa.user" // Google Pay
        )

        private val SENSITIVE_KEYWORDS = listOf(
            "password", "passcode", "pin", "cvv", "credit card",
            "secret key", "seed phrase", "otp", "2-step verification"
        )

        fun isPackageSensitive(pkg: String): Boolean {
            val lower = pkg.lowercase()
            if (SENSITIVE_PACKAGES.contains(lower)) return true
            return lower.contains("bank") || lower.contains("authenticator") || lower.contains("wallet")
        }

        fun containsSensitiveText(text: String): Boolean {
            val lower = text.lowercase()
            return SENSITIVE_KEYWORDS.any { lower.contains(it) }
        }
    }
}
