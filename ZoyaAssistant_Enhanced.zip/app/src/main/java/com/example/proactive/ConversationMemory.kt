package com.example.proactive

import android.util.Log

data class ConversationTurn(
    val speaker: String, // "user" or "zoya"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

class ConversationMemory {

    private val turns = mutableListOf<ConversationTurn>()
    private val rejectedSuggestions = mutableSetOf<String>()
    private var lastProactiveSuggestion: String? = null
    private var lastProactiveTimestamp: Long = 0L

    // Temporary quiet state if user commanded silence
    private var quietUntilTimestamp: Long = 0L

    // Active discussion topics (e.g. "api", "battery", "camera", "instagram", "setting")
    private val activeTopics = mutableSetOf<String>()

    @Synchronized
    fun addTurn(speaker: String, text: String) {
        val turn = ConversationTurn(speaker, text)
        turns.add(turn)
        if (turns.size > 20) {
            turns.removeAt(0)
        }

        val lower = text.lowercase().trim()

        if (speaker == "user") {
            // Check for silence commands
            if (isSilenceCommand(lower)) {
                Log.i("ConversationMemory", "User commanded silence: '$text'. Setting quiet mode for 10 minutes.")
                quietUntilTimestamp = System.currentTimeMillis() + (10 * 60 * 1000)
            } else if (isResumeCommand(lower)) {
                Log.i("ConversationMemory", "User resumed interaction.")
                quietUntilTimestamp = 0L
            }

            // Check if user rejected the last proactive suggestion
            if (isRejection(lower) && lastProactiveSuggestion != null) {
                lastProactiveSuggestion?.let {
                    rejectedSuggestions.add(it.lowercase())
                    Log.i("ConversationMemory", "User rejected suggestion: $it")
                }
            }

            // Extract potential topic keywords
            extractTopics(lower)
        }
    }

    @Synchronized
    fun recordProactiveIntervention(topicKey: String, messageSpoken: String) {
        lastProactiveSuggestion = topicKey
        lastProactiveTimestamp = System.currentTimeMillis()
        activeTopics.add(topicKey.lowercase())
        addTurn("zoya", messageSpoken)
    }

    @Synchronized
    fun isTopicRejected(topicKey: String): Boolean {
        return rejectedSuggestions.contains(topicKey.lowercase())
    }

    @Synchronized
    fun isQuietModeActive(): Boolean {
        return System.currentTimeMillis() < quietUntilTimestamp
    }

    @Synchronized
    fun setQuietDuration(durationMillis: Long) {
        quietUntilTimestamp = System.currentTimeMillis() + durationMillis
    }

    @Synchronized
    fun getRecentTurns(count: Int = 6): List<ConversationTurn> {
        return turns.takeLast(count)
    }

    @Synchronized
    fun hasRecentTopicMatch(screenKeywords: List<String>): Boolean {
        val screenLowers = screenKeywords.map { it.lowercase() }
        return activeTopics.any { topic -> screenLowers.any { it.contains(topic) || topic.contains(it) } }
    }

    @Synchronized
    fun getActiveTopicSnippet(): String {
        return if (activeTopics.isNotEmpty()) {
            activeTopics.take(3).joinToString(", ")
        } else "None"
    }

    private fun isSilenceCommand(text: String): Boolean {
        val silencePhrases = listOf(
            "stop talking", "be quiet", "shut up", "leave me alone",
            "don't interrupt", "dont interrupt", "don't watch my screen",
            "dont watch my screen", "quiet please", "stop speaking",
            "shh", "shush", "pause", "chup ho jao", "chup"
        )
        return silencePhrases.any { text.contains(it) }
    }

    private fun isResumeCommand(text: String): Boolean {
        val resumePhrases = listOf(
            "you can speak", "unmute", "start talking", "resume", "hey zoya", "zoya"
        )
        return resumePhrases.any { text.contains(it) }
    }

    private fun isRejection(text: String): Boolean {
        val noPhrases = listOf(
            "no", "nope", "nah", "no thanks", "don't do that", "not now", "nahi", "na"
        )
        return noPhrases.any { text == it || text.startsWith("$it ") || text.endsWith(" $it") }
    }

    private fun extractTopics(text: String) {
        val commonKeywords = listOf(
            "api", "battery", "bluetooth", "wifi", "network", "developer", "whatsapp",
            "youtube", "instagram", "setting", "email", "music", "camera", "screen",
            "update", "error", "download", "storage", "performance", "volume"
        )
        for (kw in commonKeywords) {
            if (text.contains(kw)) {
                activeTopics.add(kw)
            }
        }
        if (activeTopics.size > 8) {
            val first = activeTopics.first()
            activeTopics.remove(first)
        }
    }
}
