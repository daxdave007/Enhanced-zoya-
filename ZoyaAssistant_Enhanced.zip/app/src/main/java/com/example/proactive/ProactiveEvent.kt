package com.example.proactive

enum class ProactiveEventType {
    APP_OPENED,
    APP_CHANGED,
    SCREEN_CHANGED,
    SIGNIFICANT_UI_CHANGE,
    USER_IDLE,
    USER_INTERACTION,
    ERROR_DETECTED,
    POTENTIAL_HELP_OPPORTUNITY,
    CONVERSATION_CONTINUATION
}

data class ProactiveEvent(
    val type: ProactiveEventType,
    val screenContext: ScreenContext,
    val description: String,
    val timestamp: Long = System.currentTimeMillis()
)
