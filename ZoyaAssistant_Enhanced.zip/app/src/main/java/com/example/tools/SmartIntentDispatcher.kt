package com.example.tools

import android.content.Context
import android.util.Log
import com.example.data.ZoyaRepository
import com.example.live.PendingAction
import com.example.proactive.SmartMemoryManager
import com.example.proactive.ZoyaPreferences
import kotlinx.coroutines.flow.MutableStateFlow

class SmartIntentDispatcher(
    private val context: Context,
    private val toolEngine: ToolExecutionEngine,
    private val repository: ZoyaRepository,
    private val preferences: ZoyaPreferences,
    private val memoryManager: SmartMemoryManager
) {
    companion object {
        private const val TAG = "SmartIntentDispatcher"

        private val WAKE_PREFIX_REGEX = Regex(
            """^(?:hey\s+|ok\s+|hi\s+)?zoya\s*[,:]?\s*""",
            RegexOption.IGNORE_CASE
        )

        private val APP_LAUNCH_REGEX = Regex(
            """^(?:open|launch|start|run|go\s+to)\s+([a-zA-Z0-9\s]+)$""",
            RegexOption.IGNORE_CASE
        )

        private val CALL_REGEX = Regex(
            """^(?:call|dial|phone|ring)\s+([a-zA-Z0-9\s]+?)(?:\s+(?:on|via)\s+sim\s*([12]))?$""",
            RegexOption.IGNORE_CASE
        )

        private val TORCH_ON_REGEX = Regex(
            """^(?:turn\s+on|enable|switch\s+on|start)\s+(?:the\s+)?(?:torch|flashlight)$""",
            RegexOption.IGNORE_CASE
        )
        private val TORCH_OFF_REGEX = Regex(
            """^(?:turn\s+off|disable|switch\s+off|stop)\s+(?:the\s+)?(?:torch|flashlight)$""",
            RegexOption.IGNORE_CASE
        )

        private val VOLUME_REGEX = Regex(
            """^(?:volume\s+(up|down|mute|unmute|max)|(?:increase|raise|lower|decrease)\s+volume|set\s+volume\s+to\s+(\d+)%?)$""",
            RegexOption.IGNORE_CASE
        )

        private val SCREEN_QUERY_REGEX = Regex(
            """^(?:(?:can\s+you\s+)?(?:look\s+at|see|read|check|describe|explain)\s+(?:my\s+)?screen|(?:tell\s+me\s+)?what(?:\s+is|\s+'s|\s+do\s+you\s+see)?\s+(?:on\s+my\s+screen|on\s+the\s+screen|on\s+screen)|what\s+am\s+i\s+looking\s+at|read\s+this|what\s+should\s+i\s+press|what\s+do\s+you\s+see|describe\s+what\s+you\s+see)$""",
            RegexOption.IGNORE_CASE
        )

        private val SILENCE_REGEX = Regex(
            """^(?:stop\s+talking|be\s+quiet|shut\s+up|don't\s+talk|dont\s+talk|quiet\s+please|shh|pause|leave\s+me\s+alone|chup\s+ho\s+jao|chup)$""",
            RegexOption.IGNORE_CASE
        )

        private val WATCH_SCREEN_ON_REGEX = Regex(
            """^(?:watch\s+my\s+screen|observe\s+my\s+screen|start\s+watching\s+my\s+screen|keep\s+an\s+eye\s+on\s+my\s+screen)$""",
            RegexOption.IGNORE_CASE
        )

        private val WATCH_SCREEN_OFF_REGEX = Regex(
            """^(?:stop\s+watching\s+my\s+screen|stop\s+observing\s+my\s+screen|stop\s+watching|turn\s+off\s+screen\s+observation)$""",
            RegexOption.IGNORE_CASE
        )

        private val CONFIRM_POSITIVE_WORDS = setOf(
            "yes", "confirm", "call", "call him", "call her", "do it", "sure", "go ahead",
            "ha", "haan", "yep", "ok", "okay", "call laga do", "laga do", "proceed"
        )

        private val CONFIRM_NEGATIVE_WORDS = setOf(
            "no", "cancel", "don't call", "stop", "nahi", "mat karo", "don't", "nope", "cancel it"
        )
    }

    val pendingAction = MutableStateFlow<PendingAction?>(null)

    sealed class DispatchResult {
        data class Handled(val spokenResponse: String, val executeToolSilently: Boolean = false) : DispatchResult()
        data class NeedsConfirmation(val spokenPrompt: String, val action: PendingAction) : DispatchResult()
        data class FallthroughToAi(val cleanUtterance: String) : DispatchResult()
    }

    /**
     * Strips wake word if present (e.g. "Zoya, open YouTube" -> "open YouTube")
     */
    fun stripWakeWord(rawText: String): String {
        return rawText.replace(WAKE_PREFIX_REGEX, "").trim()
    }

    suspend fun dispatch(rawUtterance: String): DispatchResult {
        val clean = stripWakeWord(rawUtterance)
        val lower = clean.lowercase().trim()

        if (lower.isEmpty()) {
            return DispatchResult.Handled("Yes, I'm listening.")
        }

        // 1. Check for Pending Action Confirmation
        val currentPending = pendingAction.value
        if (currentPending != null) {
            if (CONFIRM_POSITIVE_WORDS.contains(lower) || lower.startsWith("yes") || lower.startsWith("confirm")) {
                val response = executePendingAction(currentPending)
                pendingAction.value = null
                return DispatchResult.Handled(response)
            } else if (CONFIRM_NEGATIVE_WORDS.contains(lower) || lower.startsWith("no") || lower.startsWith("cancel")) {
                pendingAction.value = null
                return DispatchResult.Handled("Cancelled.")
            }
        }

        // 2. Check for Smart Memory Commands ("remember ...", "forget ...")
        val memResult = memoryManager.processPotentialMemoryUtterance(clean)
        when (memResult) {
            is SmartMemoryManager.MemoryActionResult.Remembered -> {
                return DispatchResult.Handled("Got it, I'll remember that.")
            }
            is SmartMemoryManager.MemoryActionResult.Forgotten -> {
                return DispatchResult.Handled(memResult.description)
            }
            is SmartMemoryManager.MemoryActionResult.ForgetFailed -> {
                return DispatchResult.Handled(memResult.reason)
            }
            SmartMemoryManager.MemoryActionResult.NotAMemoryCommand -> {
                // Continue checking other intents
            }
        }

        // 2b. Silence Commands ("Stop talking", "Be quiet", "Don't talk")
        if (SILENCE_REGEX.matches(clean)) {
            preferences.setQuietMode(true)
            return DispatchResult.Handled("Got it, I'll stay quiet.")
        }

        // 3. Screen Observation Mode Voice Controls
        if (WATCH_SCREEN_ON_REGEX.matches(clean)) {
            preferences.setScreenAwarenessEnabled(true)
            preferences.setScreenObservationModeEnabled(true)
            return DispatchResult.Handled("Screen observation mode is active. I'll watch quietly and alert you if an error or important screen appears.")
        }
        if (WATCH_SCREEN_OFF_REGEX.matches(clean)) {
            preferences.setScreenObservationModeEnabled(false)
            return DispatchResult.Handled("Screen observation mode is now off.")
        }

        // 4. On-Demand Screen Understanding ("look at my screen", "what's on my screen")
        if (SCREEN_QUERY_REGEX.matches(clean)) {
            val snapshot = com.example.accessibility.ZoyaAccessibilityService.getCurrentScreenSnapshot()
            if (snapshot == null) {
                return if (!com.example.accessibility.ZoyaAccessibilityService.isServiceRunning()) {
                    DispatchResult.Handled("Please enable Zoya in Settings > Accessibility so I can see what is on your screen.")
                } else {
                    DispatchResult.Handled("The screen appears blank or protected right now.")
                }
            }
            if (snapshot.isSensitive || snapshot.isPasswordPresent) {
                return DispatchResult.Handled("This screen contains private or password information, so screen analysis is paused for your security.")
            }

            val appName = snapshot.appName.ifBlank { "Current App" }
            val texts = snapshot.visibleTexts.filter { it.isNotBlank() }
            val buttons = snapshot.clickableLabels

            val summary = StringBuilder("You're looking at $appName. ")
            if (snapshot.hasErrors) {
                summary.append("There seems to be an error or alert visible: ")
            } else if (snapshot.category == com.example.proactive.ScreenCategory.SETTINGS) {
                summary.append("You're in settings. ")
            } else if (snapshot.category == com.example.proactive.ScreenCategory.SOCIAL_MEDIA) {
                summary.append("You're viewing social media or a chat feed. ")
            }
            if (texts.isNotEmpty()) {
                val snippet = texts.take(4).joinToString(", ")
                summary.append("I see: $snippet.")
            }
            if (buttons.isNotEmpty()) {
                val btnSnippet = buttons.take(3).joinToString(", ")
                summary.append(" Available actions: $btnSnippet.")
            }
            return DispatchResult.Handled(summary.toString())
        }

        // 5. Direct App Launching ("Open YouTube", "Launch WhatsApp")
        val appMatch = APP_LAUNCH_REGEX.find(clean)
        if (appMatch != null) {
            val targetApp = appMatch.groupValues[1].trim()
            val result = toolEngine.execute("openApp", kotlinx.serialization.json.buildJsonObject {
                put("packageName", kotlinx.serialization.json.JsonPrimitive(targetApp))
            })
            return if (!result.startsWith("Could not find")) {
                DispatchResult.Handled("Opening $targetApp.")
            } else {
                DispatchResult.Handled(result)
            }
        }

        // 6. Direct Flashlight Controls
        if (TORCH_ON_REGEX.matches(clean)) {
            val res = toolEngine.execute("toggleTorch", kotlinx.serialization.json.buildJsonObject {
                put("state", kotlinx.serialization.json.JsonPrimitive("on"))
            })
            return DispatchResult.Handled(if (res.contains("turned on")) "Flashlight on." else res)
        }
        if (TORCH_OFF_REGEX.matches(clean)) {
            val res = toolEngine.execute("toggleTorch", kotlinx.serialization.json.buildJsonObject {
                put("state", kotlinx.serialization.json.JsonPrimitive("off"))
            })
            return DispatchResult.Handled(if (res.contains("turned off")) "Flashlight off." else res)
        }

        // 7. Volume Controls
        val volMatch = VOLUME_REGEX.find(clean)
        if (volMatch != null) {
            val dir = volMatch.groupValues[1].ifEmpty { null }
            val percent = volMatch.groupValues[2].ifEmpty { null }
            return if (percent != null) {
                val p = percent.toIntOrNull() ?: 50
                toolEngine.execute("setVolumePercent", kotlinx.serialization.json.buildJsonObject {
                    put("percent", kotlinx.serialization.json.JsonPrimitive(p))
                })
                DispatchResult.Handled("Volume set to $p%.")
            } else {
                val direction = when (dir?.lowercase()) {
                    "increase", "raise" -> "up"
                    "lower", "decrease" -> "down"
                    else -> dir ?: "up"
                }
                val res = toolEngine.execute("adjustVolume", kotlinx.serialization.json.buildJsonObject {
                    put("direction", kotlinx.serialization.json.JsonPrimitive(direction))
                })
                DispatchResult.Handled(res)
            }
        }

        // 8. Contact Calling with Smart Aliases & Action Confirmation
        val callMatch = CALL_REGEX.find(clean)
        if (callMatch != null) {
            val spokenTarget = callMatch.groupValues[1].trim()
            val simSlot = callMatch.groupValues[2].toIntOrNull()

            // Resolve relationships from smart memory (e.g. Dad <-> Papa)
            val candidateNames = repository.resolveContactAliases(spokenTarget)
            Log.d(TAG, "Resolving call target '$spokenTarget', aliases: $candidateNames")

            return handleCallingCandidates(candidateNames, spokenTarget, simSlot)
        }

        // Fall through to Gemini AI for reasoning and conversational handling
        return DispatchResult.FallthroughToAi(clean)
    }

    private suspend fun handleCallingCandidates(
        candidateNames: List<String>,
        primaryTarget: String,
        simSlot: Int?
    ): DispatchResult {
        // Query phone contacts using ToolExecutionEngine's reflection/helper
        val matches = mutableListOf<Pair<String, String>>()
        for (name in candidateNames) {
            val found = findContactsHelper(name)
            matches.addAll(found)
        }
        val distinctMatches = matches.distinctBy { it.second }

        if (distinctMatches.isEmpty()) {
            return DispatchResult.Handled("I couldn't find a phone number for '$primaryTarget' in your contacts.")
        }

        if (distinctMatches.size > 1) {
            val options = distinctMatches.take(3).joinToString(", ") { it.first }
            return DispatchResult.Handled("I found ${distinctMatches.size} contacts matching $primaryTarget: $options. Which one should I call?")
        }

        val confidentMatch = distinctMatches.first()
        val contactName = confidentMatch.first
        val number = confidentMatch.second

        // Check if user enabled direct calling in settings
        if (preferences.directCallingEnabled.value) {
            val callResult = toolEngine.execute("searchAndCallContact", kotlinx.serialization.json.buildJsonObject {
                put("contactName", kotlinx.serialization.json.JsonPrimitive(number))
                put("useDialer", kotlinx.serialization.json.JsonPrimitive(false))
                if (simSlot != null) {
                    put("simSlot", kotlinx.serialization.json.JsonPrimitive(simSlot))
                }
            })
            return DispatchResult.Handled("Calling $contactName...")
        }

        // Consequential action confirmation required!
        val action = PendingAction.Call(contactName, number, simSlot)
        pendingAction.value = action
        val prompt = "Call $contactName at $number? Say confirm or tap Call."
        return DispatchResult.NeedsConfirmation(prompt, action)
    }

    suspend fun executePendingAction(action: PendingAction): String {
        return when (action) {
            is PendingAction.Call -> {
                toolEngine.execute("searchAndCallContact", kotlinx.serialization.json.buildJsonObject {
                    put("contactName", kotlinx.serialization.json.JsonPrimitive(action.phoneNumber))
                    put("useDialer", kotlinx.serialization.json.JsonPrimitive(false))
                    if (action.simSlot != null) {
                        put("simSlot", kotlinx.serialization.json.JsonPrimitive(action.simSlot))
                    }
                })
                "Placing call to ${action.contactName}."
            }
            is PendingAction.SendWhatsApp -> {
                toolEngine.execute("sendWhatsAppMessage", kotlinx.serialization.json.buildJsonObject {
                    put("contactName", kotlinx.serialization.json.JsonPrimitive(action.contactName))
                    put("message", kotlinx.serialization.json.JsonPrimitive(action.message))
                })
                "Sending message to ${action.contactName}."
            }
            is PendingAction.DeleteMemory -> {
                repository.deleteMemory(action.memoryId)
                "Deleted from memory."
            }
        }
    }

    private fun findContactsHelper(name: String): List<Pair<String, String>> {
        val results = mutableListOf<Pair<String, String>>()
        if (context.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            return results
        }
        try {
            val uri = android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val projection = arrayOf(
                android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER
            )
            val cleanName = name.replace("'", "''")
            val selection = "${android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
            val selectionArgs = arrayOf("%$cleanName%")

            context.contentResolver.query(uri, projection, selection, selectionArgs, null)?.use { cursor ->
                val nameIdx = cursor.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = cursor.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext()) {
                    val cName = cursor.getString(nameIdx) ?: continue
                    val cNum = cursor.getString(numIdx) ?: continue
                    results.add(Pair(cName, cNum))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error finding contacts for '$name'", e)
        }
        return results
    }
}
