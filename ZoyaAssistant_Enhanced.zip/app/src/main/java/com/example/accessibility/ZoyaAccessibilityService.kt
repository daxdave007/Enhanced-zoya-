package com.example.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.proactive.ProactiveEvent
import com.example.proactive.ProactiveEventType
import com.example.proactive.ScreenCategory
import com.example.proactive.ScreenContext
import java.security.MessageDigest

class ZoyaAccessibilityService : AccessibilityService() {

    companion object {
        var shouldAutoClick = false
            set(value) {
                field = value
                if (value) {
                    Handler(Looper.getMainLooper()).postDelayed({
                        field = false
                    }, 10000) // Reset after 10 seconds to give WhatsApp time to load
                }
            }
        var targetAppName = "whatsapp"
        var instance: ZoyaAccessibilityService? = null

        // Listener for proactive screen events
        var onProactiveEventListener: ((ProactiveEvent) -> Unit)? = null

        fun isServiceRunning(): Boolean = instance != null

        fun dispatchGestureClick(x: Float, y: Float): Boolean {
            val inst = instance ?: return false
            val path = Path()
            path.moveTo(x, y)
            path.lineTo(x, y)

            val builder = GestureDescription.Builder()
            builder.addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            val gesture = builder.build()

            return inst.dispatchGesture(gesture, null, null)
        }

        fun clickTextOnScreen(text: String): Boolean {
            val inst = instance ?: return false
            val root = inst.rootInActiveWindow ?: return false
            val nodes = root.findAccessibilityNodeInfosByText(text)
            for (node in nodes) {
                var current: AccessibilityNodeInfo? = node
                while (current != null) {
                    val bounds = Rect()
                    current.getBoundsInScreen(bounds)
                    if (!bounds.isEmpty && (current.isClickable || current == node)) {
                        val x = bounds.centerX().toFloat()
                        val y = bounds.centerY().toFloat()
                        if (dispatchGestureClick(x, y)) return true
                    }
                    current = current.parent
                }
            }
            return false
        }

        suspend fun captureScreenAsBase64Jpeg(): String? {
            val inst = instance ?: return null
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                return kotlin.coroutines.suspendCoroutine { cont ->
                    try {
                        inst.takeScreenshot(
                            android.view.Display.DEFAULT_DISPLAY,
                            inst.mainExecutor,
                            object : AccessibilityService.TakeScreenshotCallback {
                                override fun onSuccess(screenshotResult: AccessibilityService.ScreenshotResult) {
                                    try {
                                        val hardwareBuffer = screenshotResult.hardwareBuffer
                                        val colorSpace = screenshotResult.colorSpace
                                        val bitmap = android.graphics.Bitmap.wrapHardwareBuffer(hardwareBuffer, colorSpace)
                                        hardwareBuffer.close()
                                        if (bitmap != null) {
                                            val softwareBitmap = bitmap.copy(android.graphics.Bitmap.Config.ARGB_8888, false)
                                            val maxDim = 1024
                                            val width = softwareBitmap.width
                                            val height = softwareBitmap.height
                                            val scale = if (width > maxDim || height > maxDim) {
                                                maxDim.toFloat() / maxOf(width, height)
                                            } else 1.0f
                                            val finalBitmap = if (scale < 1.0f) {
                                                android.graphics.Bitmap.createScaledBitmap(softwareBitmap, (width * scale).toInt(), (height * scale).toInt(), true)
                                            } else softwareBitmap

                                            val stream = java.io.ByteArrayOutputStream()
                                            finalBitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 75, stream)
                                            val base64 = android.util.Base64.encodeToString(stream.toByteArray(), android.util.Base64.NO_WRAP)
                                            cont.resumeWith(Result.success(base64))
                                        } else {
                                            cont.resumeWith(Result.success(null))
                                        }
                                    } catch (e: Exception) {
                                        Log.e("ZoyaAccessibility", "Error processing screenshot", e)
                                        cont.resumeWith(Result.success(null))
                                    }
                                }

                                override fun onFailure(errorCode: Int) {
                                    Log.e("ZoyaAccessibility", "takeScreenshot failed: $errorCode")
                                    cont.resumeWith(Result.success(null))
                                }
                            }
                        )
                    } catch (e: Exception) {
                        Log.e("ZoyaAccessibility", "Exception taking screenshot", e)
                        cont.resumeWith(Result.success(null))
                    }
                }
            }
            return null
        }

        /**
         * Mode A (On-Demand) Screen Snapshot
         */
        fun getCurrentScreenSnapshot(): ScreenContext? {
            val inst = instance ?: return null
            return inst.extractCurrentScreenContext()
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var lastPackageName: String = ""
    private var lastContentHash: String = ""
    private var lastEventTime = 0L

    private var pendingDebounceRunnable: Runnable? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i("ZoyaAccessibility", "Zoya Accessibility & Screen Awareness Service Connected")
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        // 1. Maintain existing WhatsApp auto-click automation
        if (shouldAutoClick) {
            val packageName = event.packageName?.toString() ?: ""
            if (packageName.contains("whatsapp")) {
                val rootNode = rootInActiveWindow
                if (rootNode != null) {
                    val clicked = searchAndClickSendButton(rootNode)
                    if (clicked) {
                        Log.d("ZoyaAccessibility", "Successfully clicked send button!")
                        shouldAutoClick = false
                    }
                }
            }
        }

        // 2. Mode B Proactive Screen Awareness
        handleScreenEventForProactiveAi(event)
    }

    private fun handleScreenEventForProactiveAi(event: AccessibilityEvent) {
        val eventType = event.eventType
        val packageName = event.packageName?.toString() ?: return

        // Ignore system navigation bar clicks or fast touches that don't change screen
        if (eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) {
            return
        }

        val now = System.currentTimeMillis()

        // Debounce rapid window content events (e.g. typing or animations)
        if (eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            if (now - lastEventTime < 2500L) {
                return
            }
        }

        pendingDebounceRunnable?.let { handler.removeCallbacks(it) }

        val debounceDelay = if (eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) 800L else 2000L
        val runnable = Runnable {
            processScreenSnapshot(packageName, eventType)
        }
        pendingDebounceRunnable = runnable
        handler.postDelayed(runnable, debounceDelay)
    }

    private fun processScreenSnapshot(packageName: String, eventType: Int) {
        val screenContext = extractCurrentScreenContext() ?: return

        val now = System.currentTimeMillis()
        lastEventTime = now

        val isAppChange = packageName != lastPackageName
        val isContentChange = screenContext.contentHash != lastContentHash

        if (!isAppChange && !isContentChange) {
            return
        }

        lastPackageName = packageName
        lastContentHash = screenContext.contentHash

        val proactiveType = when {
            screenContext.hasErrors -> ProactiveEventType.ERROR_DETECTED
            isAppChange -> ProactiveEventType.APP_OPENED
            isContentChange -> ProactiveEventType.SIGNIFICANT_UI_CHANGE
            else -> ProactiveEventType.SCREEN_CHANGED
        }

        val description = when (proactiveType) {
            ProactiveEventType.APP_OPENED -> "User switched to app ${screenContext.appName}"
            ProactiveEventType.ERROR_DETECTED -> "Error or warning displayed on screen"
            ProactiveEventType.SIGNIFICANT_UI_CHANGE -> "Screen content updated in ${screenContext.appName}"
            else -> "Screen updated"
        }

        val proactiveEvent = ProactiveEvent(
            type = proactiveType,
            screenContext = screenContext,
            description = description
        )

        onProactiveEventListener?.invoke(proactiveEvent)
    }

    private fun extractCurrentScreenContext(): ScreenContext? {
        val rootNode = rootInActiveWindow ?: return null

        val packageName = rootNode.packageName?.toString() ?: ""
        if (packageName.isBlank()) return null

        val appName = try {
            val pm = packageManager
            val appInfo = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(appInfo).toString()
        } catch (e: Exception) {
            packageName.substringAfterLast('.')
        }

        val isSensitivePkg = ScreenContext.isPackageSensitive(packageName)
        val texts = mutableListOf<String>()
        val clickableLabels = mutableListOf<String>()
        var isPasswordFound = false
        var hasErrors = false

        // Traverse UI hierarchy safely (max depth 6, max 50 nodes)
        fun traverse(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || depth > 6 || texts.size > 25) return

            if (node.isPassword) {
                isPasswordFound = true
            }

            val text = node.text?.toString()?.trim()
            val desc = node.contentDescription?.toString()?.trim()

            if (!text.isNullOrBlank()) {
                if (ScreenContext.containsSensitiveText(text)) {
                    isPasswordFound = true
                }
                texts.add(text)
                val lower = text.lowercase()
                if (lower.contains("error") || lower.contains("failed") || lower.contains("unable to") || lower.contains("invalid")) {
                    hasErrors = true
                }
            } else if (!desc.isNullOrBlank()) {
                texts.add(desc)
            }

            if (node.isClickable && !text.isNullOrBlank() && clickableLabels.size < 10) {
                clickableLabels.add(text)
            }

            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                traverse(child, depth + 1)
            }
        }

        traverse(rootNode, 0)

        val windowTitle = rootNode.viewIdResourceName ?: ""
        val category = determineCategory(packageName, appName, texts)

        // Compute hash of content for fast duplicate/change comparison
        val combinedContent = "$packageName|" + texts.joinToString(";")
        val contentHash = computeHash(combinedContent)

        return ScreenContext(
            packageName = packageName,
            appName = appName,
            windowTitle = windowTitle,
            visibleTexts = texts,
            clickableLabels = clickableLabels,
            isSensitive = isSensitivePkg,
            isPasswordPresent = isPasswordFound,
            contentHash = contentHash,
            hasErrors = hasErrors,
            category = category
        )
    }

    private fun determineCategory(pkg: String, name: String, texts: List<String>): ScreenCategory {
        val lowerPkg = pkg.lowercase()
        val lowerName = name.lowercase()
        val textSnippet = texts.take(10).joinToString(" ").lowercase()

        return when {
            textSnippet.contains("error") || textSnippet.contains("crash") || textSnippet.contains("failed") -> ScreenCategory.ERROR_DIALOG
            lowerPkg.contains("settings") && (textSnippet.contains("developer") || textSnippet.contains("usb debugging")) -> ScreenCategory.DEVELOPER
            lowerPkg.contains("settings") -> ScreenCategory.SETTINGS
            lowerPkg.contains("instagram") || lowerPkg.contains("twitter") || lowerPkg.contains("reddit") || lowerPkg.contains("facebook") || lowerPkg.contains("tiktok") -> ScreenCategory.SOCIAL_MEDIA
            lowerPkg.contains("chrome") || lowerPkg.contains("firefox") || lowerPkg.contains("browser") -> ScreenCategory.BROWSER
            lowerPkg.contains("youtube") || lowerPkg.contains("spotify") || lowerPkg.contains("music") || lowerPkg.contains("netflix") -> ScreenCategory.MEDIA_PLAYER
            lowerPkg.contains("whatsapp") || lowerPkg.contains("messaging") || lowerPkg.contains("telegram") -> ScreenCategory.COMMUNICATION
            lowerPkg.contains("systemui") -> ScreenCategory.SYSTEM_UI
            else -> ScreenCategory.GENERAL
        }
    }

    private fun computeHash(input: String): String {
        return try {
            val md = MessageDigest.getInstance("MD5")
            val digest = md.digest(input.toByteArray())
            digest.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            input.hashCode().toString()
        }
    }

    private fun searchAndClickSendButton(node: AccessibilityNodeInfo): Boolean {
        val idsToTry = listOf(
            "com.whatsapp:id/send",
            "com.whatsapp.w4b:id/send"
        )
        for (id in idsToTry) {
            val sendButtons = node.findAccessibilityNodeInfosByViewId(id)
            if (sendButtons.isNotEmpty()) {
                for (button in sendButtons) {
                    if (performClick(button)) {
                        Log.d("ZoyaAccessibility", "Clicked send button by ID: $id")
                        return true
                    }
                }
            }
        }
        return recursiveSearchAndClick(node)
    }

    private fun recursiveSearchAndClick(node: AccessibilityNodeInfo): Boolean {
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        if (desc == "send" || desc == "bheje" || desc == "bhejen" || desc == "envio") {
            if (performClick(node)) {
                Log.d("ZoyaAccessibility", "Clicked send button by content description!")
                return true
            }
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            if (child != null) {
                if (recursiveSearchAndClick(child)) {
                    return true
                }
            }
        }
        return false
    }

    private fun performClick(node: AccessibilityNodeInfo): Boolean {
        val bounds = Rect()
        node.getBoundsInScreen(bounds)
        if (!bounds.isEmpty) {
            val x = bounds.centerX().toFloat()
            val y = bounds.centerY().toFloat()
            if (dispatchGestureClick(x, y)) {
                return true
            }
        }

        if (node.isClickable) {
            val success = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            if (success) return true
        }
        var parent = node.parent
        while (parent != null) {
            if (parent.isClickable) {
                val success = parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                if (success) return true
            }
            parent = parent.parent
        }
        return false
    }

    override fun onInterrupt() {
        Log.d("ZoyaAccessibility", "Accessibility Service Interrupted")
    }
}
