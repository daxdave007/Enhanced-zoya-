package com.example.ui

import android.content.Intent
import android.os.Build
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ZoyaForegroundService
import com.example.live.ZoyaState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.border

import androidx.compose.foundation.BorderStroke
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.TextField
import androidx.compose.material3.OutlinedButton
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.collectAsState
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ZoyaDatabase
import com.example.data.ZoyaRepository

import android.content.Context
import android.net.Uri
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.NotificationsOff
import com.example.accessibility.ZoyaAccessibilityService
import com.example.proactive.ZoyaPreferences



@Composable
fun ZoyaScreen() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            HomeScreen(
                onNavigateToChat = { navController.navigate("chat") }
            )
        }
        composable("chat") {
            ChatScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onNavigateToChat: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("ZoyaPrefs", Context.MODE_PRIVATE) }
    val preferences = remember { ZoyaPreferences.getInstance(context) }
    val proactiveEnabled by preferences.proactiveEnabled.collectAsState()
    val screenAwarenessEnabled by preferences.screenAwarenessEnabled.collectAsState()
    val voiceResponsesEnabled by preferences.voiceResponsesEnabled.collectAsState()
    val quietMode by preferences.quietMode.collectAsState()

    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var showApiKeyDialog by remember { mutableStateOf(apiKey.isEmpty()) }
    var showProactiveSettingsDialog by remember { mutableStateOf(false) }
    var zoyaState by remember { mutableStateOf(ZoyaForegroundService.currentState) }
    var serviceStarted by remember { mutableStateOf(ZoyaForegroundService.activeService != null) }
    var isAccessibilityRunning by remember { mutableStateOf(ZoyaAccessibilityService.isServiceRunning()) }
    var showMenu by remember { mutableStateOf(false) }

    val amplitude by ZoyaForegroundService.audioAmplitude.collectAsStateWithLifecycle(0f)
    val pendingAction by ZoyaForegroundService.pendingAction.collectAsStateWithLifecycle(null)
    val database = remember { ZoyaDatabase.getDatabase(context) }
    val repository = remember { ZoyaRepository(database.zoyaDao()) }
    var selectedTab by remember { androidx.compose.runtime.mutableIntStateOf(0) }

    val permissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions[android.Manifest.permission.RECORD_AUDIO] == true) {
            // Permission approval alone must never start Zoya.
            // The user explicitly starts the assistant from the UI.
            serviceStarted = ZoyaForegroundService.activeService != null
        } else {
            android.widget.Toast.makeText(context, "Microphone permission is required!", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(Unit) {
        ZoyaForegroundService.onStateChange = { state ->
            zoyaState = state
        }
        while (true) {
            isAccessibilityRunning = ZoyaAccessibilityService.isServiceRunning()
            serviceStarted = ZoyaForegroundService.activeService != null
            delay(2000)
        }
    }

    androidx.compose.material3.Scaffold(
        topBar = {
            androidx.compose.material3.TopAppBar(
                title = { Text("Z.O.Y.A.", color = Color.White, fontWeight = FontWeight.Light, fontSize = 24.sp, letterSpacing = 2.sp) },
                colors = androidx.compose.material3.TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                ),
                actions = {
                    androidx.compose.material3.IconButton(
                        onClick = { showMenu = !showMenu },
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                    ) {
                        Text("⚙", color = Color.White, fontSize = 20.sp)
                    }
                    androidx.compose.material3.DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false },
                        modifier = Modifier
                            .background(Color(0xFF1E1E2E).copy(alpha = 0.9f))
                            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                    ) {
                        androidx.compose.material3.DropdownMenuItem(
                            text = { Text("View Logs", color = Color.White) },
                            onClick = {
                                showMenu = false
                                onNavigateToChat()
                            }
                        )
                        androidx.compose.material3.DropdownMenuItem(
                            text = { Text("Proactive & Screen Controls", color = Color.White) },
                            onClick = {
                                showMenu = false
                                showProactiveSettingsDialog = true
                            }
                        )
                        androidx.compose.material3.DropdownMenuItem(
                            text = { Text("API Key Settings", color = Color.White) },
                            onClick = {
                                showMenu = false
                                showApiKeyDialog = true
                            }
                        )
                        androidx.compose.material3.DropdownMenuItem(
                            text = { Text("Accessibility Settings (Auto-Click)", color = Color.White) },
                            onClick = {
                                showMenu = false
                                val intent = Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                context.startActivity(intent)
                            }
                        )
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF141422).copy(alpha = 0.98f),
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Text("✦", fontSize = 18.sp) },
                    label = { Text("Assistant", fontSize = 11.sp, fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF00E5FF),
                        selectedTextColor = Color(0xFF00E5FF),
                        indicatorColor = Color(0xFF00E5FF).copy(alpha = 0.15f),
                        unselectedIconColor = Color.White.copy(alpha = 0.5f),
                        unselectedTextColor = Color.White.copy(alpha = 0.5f)
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Text("🧠", fontSize = 18.sp) },
                    label = { Text("Memory & Rules", fontSize = 11.sp, fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFFB388FF),
                        selectedTextColor = Color(0xFFB388FF),
                        indicatorColor = Color(0xFFB388FF).copy(alpha = 0.15f),
                        unselectedIconColor = Color.White.copy(alpha = 0.5f),
                        unselectedTextColor = Color.White.copy(alpha = 0.5f)
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Text("📜", fontSize = 18.sp) },
                    label = { Text("Transcripts", fontSize = 11.sp, fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFFFFD180),
                        selectedTextColor = Color(0xFFFFD180),
                        indicatorColor = Color(0xFFFFD180).copy(alpha = 0.15f),
                        unselectedIconColor = Color.White.copy(alpha = 0.5f),
                        unselectedTextColor = Color.White.copy(alpha = 0.5f)
                    )
                )
            }
        },
        containerColor = Color.Transparent
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    androidx.compose.ui.graphics.Brush.radialGradient(
                        colors = listOf(Color(0xFF1A1A2E), Color(0xFF0F0F1A)),
                        radius = 1500f
                    )
                )
                .padding(paddingValues),
            contentAlignment = Alignment.Center
        ) {
            when (selectedTab) {
                0 -> {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .padding(24.dp)
                            .background(
                                color = Color.White.copy(alpha = 0.05f),
                                shape = RoundedCornerShape(32.dp)
                            )
                            .border(
                                width = 1.dp,
                                color = Color.White.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(32.dp)
                            )
                            .padding(horizontal = 24.dp, vertical = 20.dp)
                    ) {
                        Spacer(modifier = Modifier.height(10.dp))
                        
                        // Live Audio Waveform Animated Orb
                        ZoyaOrb(state = zoyaState, amplitude = amplitude)
                        
                        Spacer(modifier = Modifier.height(12.dp))

                        // Upgraded Live Waveform Bar Visualizer (AudioRecord & AudioTrack)
                        LiveAudioWaveformBarVisualizer(state = zoyaState, amplitude = amplitude)

                        Spacer(modifier = Modifier.height(14.dp))

                        // Proactive Status Badges
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val proactiveColor = if (proactiveEnabled) Color(0xFF00E5FF) else Color.Gray
                            Box(
                                modifier = Modifier
                                    .background(proactiveColor.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                                    .border(1.dp, proactiveColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                    .clickable { showProactiveSettingsDialog = true }
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                            ) {
                                Text(
                                    text = if (proactiveEnabled) "✦ Proactive ON" else "✦ Proactive OFF",
                                    color = proactiveColor,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            val screenColor = if (screenAwarenessEnabled && isAccessibilityRunning) {
                                Color(0xFF00E676)
                            } else if (screenAwarenessEnabled) {
                                Color(0xFFFFB300)
                            } else Color.Gray

                            Box(
                                modifier = Modifier
                                    .background(screenColor.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                                    .border(1.dp, screenColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                    .clickable {
                                        if (!isAccessibilityRunning) {
                                            val intent = Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                            context.startActivity(intent)
                                        } else {
                                            showProactiveSettingsDialog = true
                                        }
                                    }
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                            ) {
                                Text(
                                    text = if (screenAwarenessEnabled && isAccessibilityRunning) "👁 Screen Aware"
                                           else if (screenAwarenessEnabled) "👁 Tap for Access"
                                           else "👁 Screen OFF",
                                    color = screenColor,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            if (quietMode) {
                                Box(
                                    modifier = Modifier
                                        .background(Color(0xFFB388FF).copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                                        .border(1.dp, Color(0xFFB388FF).copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                    .clickable { preferences.setQuietMode(false) }
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                                ) {
                                    Text("🤫 Quiet Mode", color = Color(0xFFB388FF), fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        if (!serviceStarted) {
                            if (apiKey.isEmpty()) {
                                androidx.compose.material3.Button(
                                    modifier = Modifier.testTag("setup_api_button"),
                                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                                        containerColor = Color.White.copy(alpha = 0.1f),
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(24.dp),
                                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                                    onClick = {
                                        showApiKeyDialog = true
                                    }
                                ) {
                                    Text("Setup API Key", fontWeight = FontWeight.Medium, fontSize = 16.sp, modifier = Modifier.padding(vertical = 8.dp, horizontal = 16.dp))
                                }
                            } else {
                                androidx.compose.material3.Button(
                                    modifier = Modifier.testTag("start_zoya_button"),
                                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                                        containerColor = Color.White.copy(alpha = 0.1f),
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(24.dp),
                                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                                    onClick = {
                                        val hasMic = ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED
                                        val hasContacts = ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_CONTACTS) == android.content.pm.PackageManager.PERMISSION_GRANTED
                                        val hasPhone = ContextCompat.checkSelfPermission(context, android.Manifest.permission.CALL_PHONE) == android.content.pm.PackageManager.PERMISSION_GRANTED
                                        
                                        if (hasMic && hasContacts && hasPhone) {
                                            val intent = Intent(context, ZoyaForegroundService::class.java)
                                            ContextCompat.startForegroundService(context, intent)
                                            serviceStarted = true
                                        } else {
                                            permissionLauncher.launch(
                                                arrayOf(
                                                    android.Manifest.permission.RECORD_AUDIO,
                                                    android.Manifest.permission.READ_CONTACTS,
                                                    android.Manifest.permission.CALL_PHONE
                                                )
                                            )
                                        }
                                    }
                                ) {
                                    Text("Initialize Z.O.Y.A.", fontWeight = FontWeight.Medium, fontSize = 16.sp, modifier = Modifier.padding(vertical = 8.dp, horizontal = 16.dp))
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                androidx.compose.material3.OutlinedButton(
                                    onClick = { showProactiveSettingsDialog = true },
                                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                                    shape = RoundedCornerShape(20.dp)
                                ) {
                                    Text("⚙ Proactive Controls", color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
                                }
                            }
                        } else if (zoyaState == ZoyaState.IDLE) {
                            androidx.compose.material3.Button(
                                colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                                    containerColor = Color.White.copy(alpha = 0.1f),
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(24.dp),
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                                onClick = {
                                    val service = ZoyaForegroundService.activeService
                                    if (service != null) {
                                        service.reconnectSession()
                                    } else {
                                        val intent = Intent(context, ZoyaForegroundService::class.java)
                                        ContextCompat.startForegroundService(context, intent)
                                    }
                                }
                            ) {
                                Text("Start Zoya", fontWeight = FontWeight.Medium, fontSize = 16.sp, modifier = Modifier.padding(vertical = 8.dp, horizontal = 16.dp))
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            androidx.compose.material3.OutlinedButton(
                                onClick = { showProactiveSettingsDialog = true },
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Text("⚙ Controls", color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
                            }
                            
                            Spacer(modifier = Modifier.height(12.dp))
                            
                            androidx.compose.material3.Button(
                                onClick = {
                                    val intent = Intent(context, ZoyaForegroundService::class.java)
                                    context.stopService(intent)
                                    serviceStarted = false
                                },
                                colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFE53935).copy(alpha = 0.2f),
                                    contentColor = Color(0xFFEF9A9A)
                                ),
                                border = BorderStroke(1.dp, Color(0xFFE53935).copy(alpha = 0.3f)),
                                shape = RoundedCornerShape(24.dp)
                            ) {
                                Text("Terminate Session", fontWeight = FontWeight.Medium, fontSize = 16.sp, modifier = Modifier.padding(vertical = 8.dp, horizontal = 16.dp))
                            }
                        } else {
                            Text(
                                text = when (zoyaState) {
                                    ZoyaState.STANDBY -> "✦ Standby (Say 'Zoya')..."
                                    ZoyaState.LISTENING -> "Awaiting Input..."
                                    ZoyaState.USER_SPEAKING -> "Listening to you..."
                                    ZoyaState.THINKING -> "Processing..."
                                    ZoyaState.SPEAKING -> "Zoya Speaking..."
                                    ZoyaState.INTERRUPTED -> "Interrupted..."
                                    ZoyaState.ERROR -> "Connection Error"
                                    else -> "Idle"
                                },
                                color = Color.White.copy(alpha = 0.9f),
                                fontWeight = FontWeight.Medium,
                                fontSize = 18.sp,
                                modifier = Modifier
                                    .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
                                    .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(16.dp))
                                    .padding(horizontal = 24.dp, vertical = 12.dp)
                            )

                            // Prominent STOP button when AI is actively speaking or processing
                            if (zoyaState == ZoyaState.SPEAKING || zoyaState == ZoyaState.THINKING) {
                                Spacer(modifier = Modifier.height(12.dp))
                                androidx.compose.material3.Button(
                                    modifier = Modifier
                                        .testTag("stop_speech_button")
                                        .height(48.dp)
                                        .padding(horizontal = 4.dp),
                                    onClick = {
                                        ZoyaForegroundService.stopPlaybackAndSpeech()
                                        android.widget.Toast.makeText(context, "⏹ Speech Stopped", android.widget.Toast.LENGTH_SHORT).show()
                                    },
                                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFFFF1744),
                                        contentColor = Color.White
                                    ),
                                    elevation = androidx.compose.material3.ButtonDefaults.buttonElevation(defaultElevation = 6.dp),
                                    shape = RoundedCornerShape(24.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text("⏹", fontSize = 16.sp)
                                        Text("STOP", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    }
                                }
                            }

                            if (pendingAction != null) {
                                Spacer(modifier = Modifier.height(14.dp))
                                ActionConfirmationCard(
                                    action = pendingAction!!,
                                    onConfirm = {
                                        val action = pendingAction ?: return@ActionConfirmationCard
                                        ZoyaForegroundService.pendingAction.value = null
                                        val service = ZoyaForegroundService.activeService
                                        if (service != null) {
                                            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                                                val res = service.smartIntentDispatcher.executePendingAction(action)
                                                service.liveSessionManager.speakTextDirect(res)
                                            }
                                        }
                                    },
                                    onCancel = {
                                        ZoyaForegroundService.pendingAction.value = null
                                        val service = ZoyaForegroundService.activeService
                                        service?.liveSessionManager?.speakTextDirect("Cancelled.")
                                    }
                                )
                            }
                            
                            Spacer(modifier = Modifier.height(16.dp))

                            // Action Buttons Row: Screen Awareness, Inspect Screen, Vision Snapshot, Controls
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val screenAwarenessOn by preferences.screenAwarenessEnabled.collectAsState()
                                androidx.compose.material3.Button(
                                    modifier = Modifier.testTag("screen_awareness_button"),
                                    onClick = {
                                        if (!ZoyaAccessibilityService.isServiceRunning()) {
                                            val intent = Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                                                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                            }
                                            context.startActivity(intent)
                                            android.widget.Toast.makeText(context, "Enable Zoya in Accessibility Settings to share screen.", android.widget.Toast.LENGTH_LONG).show()
                                        } else {
                                            val nextState = !screenAwarenessOn
                                            preferences.setScreenAwarenessEnabled(nextState)
                                            android.widget.Toast.makeText(context, if (nextState) "🟢 Screen Awareness Active" else "⚪ Screen Awareness Paused", android.widget.Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                                        containerColor = if (screenAwarenessOn) Color(0xFF00E676).copy(alpha = 0.2f) else Color.White.copy(alpha = 0.08f),
                                        contentColor = if (screenAwarenessOn) Color(0xFF69F0AE) else Color.White.copy(alpha = 0.7f)
                                    ),
                                    border = BorderStroke(1.dp, if (screenAwarenessOn) Color(0xFF00E676).copy(alpha = 0.5f) else Color.White.copy(alpha = 0.2f)),
                                    shape = RoundedCornerShape(20.dp)
                                ) {
                                    Text(if (screenAwarenessOn) "🟢 Screen" else "⚪ Screen", fontSize = 11.sp)
                                }

                                androidx.compose.material3.Button(
                                    modifier = Modifier.testTag("inspect_screen_button"),
                                    onClick = {
                                        val snapshot = ZoyaAccessibilityService.getCurrentScreenSnapshot()
                                        if (snapshot != null) {
                                            val service = ZoyaForegroundService.activeService
                                            service?.liveSessionManager?.triggerProactiveSpeech(
                                                "[ON-DEMAND SCREEN UNDERSTANDING]: The user clicked 'Inspect Screen'. Current screen snapshot: ${snapshot.toSummaryString()}.",
                                                snapshot.toSummaryString()
                                            )
                                            android.widget.Toast.makeText(context, "Observing: ${snapshot.appName}", android.widget.Toast.LENGTH_SHORT).show()
                                        } else {
                                            android.widget.Toast.makeText(context, "Please enable Zoya in Accessibility Settings to inspect screens.", android.widget.Toast.LENGTH_LONG).show()
                                        }
                                    },
                                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF00E5FF).copy(alpha = 0.15f),
                                        contentColor = Color(0xFF80D8FF)
                                    ),
                                    border = BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.3f)),
                                    shape = RoundedCornerShape(20.dp)
                                ) {
                                    Text("👁 Inspect", fontSize = 11.sp)
                                }

                                androidx.compose.material3.Button(
                                    modifier = Modifier.testTag("vision_snapshot_button"),
                                    onClick = {
                                        val service = ZoyaForegroundService.activeService
                                        if (service != null) {
                                            service.liveSessionManager.captureAndSendVisionSnapshot()
                                            android.widget.Toast.makeText(context, "📸 Transmitting vision screenshot...", android.widget.Toast.LENGTH_SHORT).show()
                                        } else {
                                            android.widget.Toast.makeText(context, "Start Zoya session first.", android.widget.Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFFFFB74D).copy(alpha = 0.15f),
                                        contentColor = Color(0xFFFFE082)
                                    ),
                                    border = BorderStroke(1.dp, Color(0xFFFFB74D).copy(alpha = 0.3f)),
                                    shape = RoundedCornerShape(20.dp)
                                ) {
                                    Text("📸 Vision", fontSize = 11.sp)
                                }

                                androidx.compose.material3.OutlinedButton(
                                    onClick = { showProactiveSettingsDialog = true },
                                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                                    shape = RoundedCornerShape(20.dp)
                                ) {
                                    Text("⚙ Controls", color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)
                                }
                            }
                            
                            Spacer(modifier = Modifier.height(14.dp))
                            
                            androidx.compose.material3.Button(
                                onClick = {
                                    val intent = Intent(context, ZoyaForegroundService::class.java)
                                    context.stopService(intent)
                                    serviceStarted = false
                                },
                                colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFE53935).copy(alpha = 0.2f),
                                    contentColor = Color(0xFFEF9A9A)
                                ),
                                border = BorderStroke(1.dp, Color(0xFFE53935).copy(alpha = 0.3f)),
                                shape = RoundedCornerShape(24.dp)
                            ) {
                                Text("Disconnect", fontWeight = FontWeight.Medium, fontSize = 15.sp, modifier = Modifier.padding(vertical = 6.dp, horizontal = 14.dp))
                            }
                        }
                    }
                }
                1 -> {
                    PersonalizationStorageView(
                        repository = repository,
                        preferences = preferences
                    )
                }
                2 -> {
                    TranscriptHistoryView(
                        repository = repository
                    )
                }
            }
        }
    }    
    if (showApiKeyDialog) {
        var tempKey by remember { mutableStateOf(apiKey) }
        AlertDialog(
            onDismissRequest = { showApiKeyDialog = false },
            title = { Text("Gemini API Key") },
            text = {
                Column {
                    Text("Enter your Gemini API key to use Z.O.Y.A.")
                    Spacer(modifier = Modifier.height(8.dp))
                    TextField(
                        value = tempKey,
                        onValueChange = { tempKey = it },
                        placeholder = { Text("AIza...") },
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        trailingIcon = {
                            if (tempKey.isNotEmpty()) {
                                androidx.compose.material3.IconButton(onClick = { tempKey = "" }) {
                                    androidx.compose.material3.Icon(
                                        imageVector = Icons.Filled.Clear,
                                        contentDescription = "Clear text"
                                    )
                                }
                            }
                        }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Get your API key here",
                        color = Color(0xFF00B0FF),
                        modifier = Modifier.clickable {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/app/apikey"))
                            context.startActivity(intent)
                        }
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        prefs.edit().putString("api_key", tempKey).apply()
                        apiKey = tempKey
                        showApiKeyDialog = false
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showApiKeyDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showProactiveSettingsDialog) {
        ProactiveSettingsDialog(
            preferences = preferences,
            isAccessibilityRunning = isAccessibilityRunning,
            onDismiss = { showProactiveSettingsDialog = false }
        )
    }

}

@Composable
fun ProactiveSettingsDialog(
    preferences: ZoyaPreferences,
    isAccessibilityRunning: Boolean,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val proactiveEnabled by preferences.proactiveEnabled.collectAsState()
    val screenAwarenessEnabled by preferences.screenAwarenessEnabled.collectAsState()
    val voiceResponsesEnabled by preferences.voiceResponsesEnabled.collectAsState()
    val quietMode by preferences.quietMode.collectAsState()
    val wakeWordEnabled by preferences.wakeWordEnabled.collectAsState()
    val directCallingEnabled by preferences.directCallingEnabled.collectAsState()
    val screenObservationModeEnabled by preferences.screenObservationModeEnabled.collectAsState()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "Companion & Screen Controls",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = Color.White
            )
        },
        containerColor = Color(0xFF1E1E2E),
        titleContentColor = Color.White,
        textContentColor = Color.White.copy(alpha = 0.85f),
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 1. Proactive AI toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Proactive AI", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        Text(
                            "Zoya occasionally initiates conversations, gives advice, or reacts to screen events.",
                            color = Color.White.copy(alpha = 0.65f),
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = proactiveEnabled,
                        onCheckedChange = { preferences.setProactiveEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF00E5FF),
                            checkedTrackColor = Color(0xFF00B0FF).copy(alpha = 0.5f)
                        )
                    )
                }

                // 2. Screen Awareness toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Screen Awareness", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        Text(
                            "Understands what is on screen to provide contextual suggestions. Sensitive data is protected.",
                            color = Color.White.copy(alpha = 0.65f),
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = screenAwarenessEnabled,
                        onCheckedChange = { preferences.setScreenAwarenessEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF00E676),
                            checkedTrackColor = Color(0xFF00E676).copy(alpha = 0.5f)
                        )
                    )
                }

                // 3. Voice Responses toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Voice Responses", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        Text(
                            "Speaks out loud. If disabled, observations are saved to logs only.",
                            color = Color.White.copy(alpha = 0.65f),
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = voiceResponsesEnabled,
                        onCheckedChange = { preferences.setVoiceResponsesEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFFB388FF),
                            checkedTrackColor = Color(0xFF651FFF).copy(alpha = 0.5f)
                        )
                    )
                }

                // 4. Quiet Mode toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Quiet Mode", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        Text(
                            "Temporarily suppress proactive speaking until turned off or user speaks.",
                            color = Color.White.copy(alpha = 0.65f),
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = quietMode,
                        onCheckedChange = { preferences.setQuietMode(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFFFFB300),
                            checkedTrackColor = Color(0xFFFF9100).copy(alpha = 0.5f)
                        )
                    )
                }

                // 5. Wake Word ('Zoya')
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Wake Word ('Zoya')", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        Text(
                            "Activates Zoya when you say 'Zoya' in standby mode.",
                            color = Color.White.copy(alpha = 0.65f),
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = wakeWordEnabled,
                        onCheckedChange = { preferences.setWakeWordEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF00E5FF),
                            checkedTrackColor = Color(0xFF00E5FF).copy(alpha = 0.5f)
                        )
                    )
                }

                // 6. Direct Calling toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Direct Calling", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        Text(
                            "Skip confirmation when placing phone calls. When off, Zoya asks before dialing.",
                            color = Color.White.copy(alpha = 0.65f),
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = directCallingEnabled,
                        onCheckedChange = { preferences.setDirectCallingEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF69F0AE),
                            checkedTrackColor = Color(0xFF00E676).copy(alpha = 0.5f)
                        )
                    )
                }

                // 7. Screen Observation Mode
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Screen Observation Mode", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        Text(
                            "Zoya quietly observes the screen and offers help only if errors or important screens appear.",
                            color = Color.White.copy(alpha = 0.65f),
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = screenObservationModeEnabled,
                        onCheckedChange = { preferences.setScreenObservationModeEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFFFFD180),
                            checkedTrackColor = Color(0xFFFF9100).copy(alpha = 0.5f)
                        )
                    )
                }

                // Accessibility Service Card
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            if (isAccessibilityRunning) Color(0xFF00E676).copy(alpha = 0.1f)
                            else Color(0xFFFF9100).copy(alpha = 0.1f),
                            RoundedCornerShape(12.dp)
                        )
                        .border(
                            1.dp,
                            if (isAccessibilityRunning) Color(0xFF00E676).copy(alpha = 0.3f)
                            else Color(0xFFFF9100).copy(alpha = 0.4f),
                            RoundedCornerShape(12.dp)
                        )
                        .padding(12.dp)
                ) {
                    Text(
                        text = if (isAccessibilityRunning) "✓ Accessibility Service Connected"
                               else "⚠ Accessibility Service Inactive",
                        color = if (isAccessibilityRunning) Color(0xFF69F0AE) else Color(0xFFFFD180),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Android Accessibility is required for Zoya to observe UI changes and perform auto-clicks.",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = {
                            val intent = Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)
                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            context.startActivity(intent)
                        },
                        colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(
                            contentColor = Color.White
                        ),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.3f)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Open Accessibility Settings", fontSize = 12.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Done", color = Color(0xFF00B0FF))
            }
        }
    )
}



@Composable
fun ZoyaOrb(state: ZoyaState, amplitude: Float = 0f) {
    val radiusScale = remember { Animatable(1f) }
    val glowAlpha = remember { Animatable(0.5f) }
    val rotateAngle = remember { Animatable(0f) }
    
    // Ring rotations
    val ring1Angle = remember { Animatable(0f) }
    val ring2Angle = remember { Animatable(120f) }
    val ring3Angle = remember { Animatable(240f) }
    val ring4Angle = remember { Animatable(45f) }

    LaunchedEffect(state) {
        when (state) {
            ZoyaState.STANDBY -> {
                radiusScale.animateTo(1.0f, animationSpec = tween(800))
                glowAlpha.animateTo(
                    targetValue = 0.5f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(2000, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    )
                )
            }
            ZoyaState.IDLE -> {
                radiusScale.animateTo(1f, animationSpec = tween(1000))
                glowAlpha.animateTo(
                    targetValue = 0.4f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(2500, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    )
                )
            }
            ZoyaState.LISTENING -> {
                radiusScale.animateTo(1.1f, animationSpec = tween(500))
                glowAlpha.animateTo(
                    targetValue = 0.8f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(800, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    )
                )
            }
            ZoyaState.USER_SPEAKING -> {
                radiusScale.animateTo(1.25f, animationSpec = tween(150))
                glowAlpha.animateTo(
                    targetValue = 1.0f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(250, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    )
                )
            }
            ZoyaState.THINKING -> {
                radiusScale.animateTo(1.05f, animationSpec = tween(400))
                glowAlpha.animateTo(
                    targetValue = 0.6f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1200, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    )
                )
            }
            ZoyaState.SPEAKING -> {
                radiusScale.animateTo(1.2f, animationSpec = tween(200))
                glowAlpha.animateTo(
                    targetValue = 1f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(300, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    )
                )
            }
            ZoyaState.INTERRUPTED -> {
                radiusScale.animateTo(0.95f, animationSpec = tween(100))
                glowAlpha.animateTo(0.9f, animationSpec = tween(100))
            }
            ZoyaState.ERROR -> {
                radiusScale.animateTo(1f, animationSpec = tween(300))
                glowAlpha.animateTo(0.5f, animationSpec = tween(300))
            }
        }
    }

    // Continuous rotation for rings
    LaunchedEffect(Unit) {
        launch {
            ring1Angle.animateTo(
                targetValue = 360f,
                animationSpec = infiniteRepeatable(
                    animation = tween(6000, easing = androidx.compose.animation.core.LinearEasing),
                    repeatMode = RepeatMode.Restart
                )
            )
        }
        launch {
            ring2Angle.animateTo(
                targetValue = 360f + 120f,
                animationSpec = infiniteRepeatable(
                    animation = tween(7000, easing = androidx.compose.animation.core.LinearEasing),
                    repeatMode = RepeatMode.Restart
                )
            )
        }
        launch {
            ring3Angle.animateTo(
                targetValue = 360f + 240f,
                animationSpec = infiniteRepeatable(
                    animation = tween(5500, easing = androidx.compose.animation.core.LinearEasing),
                    repeatMode = RepeatMode.Restart
                )
            )
        }
        launch {
            ring4Angle.animateTo(
                targetValue = -360f + 45f, // reverse rotation
                animationSpec = infiniteRepeatable(
                    animation = tween(8000, easing = androidx.compose.animation.core.LinearEasing),
                    repeatMode = RepeatMode.Restart
                )
            )
        }
    }

    Box(
        modifier = Modifier.size(280.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val baseRadius = size.minDimension / 4f
            val dynamicScale = radiusScale.value + (amplitude * 0.35f)
            val currentRadius = baseRadius * dynamicScale
            
            // Core colors based on state
            val coreInnerColor = when (state) {
                ZoyaState.IDLE -> Color(0xFF80D8FF)
                ZoyaState.STANDBY -> Color(0xFF80DEEA)
                ZoyaState.LISTENING -> Color(0xFFB388FF)
                ZoyaState.USER_SPEAKING -> Color(0xFF00E5FF)
                ZoyaState.THINKING -> Color(0xFFFFD180)
                ZoyaState.SPEAKING -> Color(0xFF69F0AE)
                ZoyaState.INTERRUPTED -> Color(0xFFFF8A80)
                ZoyaState.ERROR -> Color(0xFFEF5350)
            }
            
            val coreOuterColor = when (state) {
                ZoyaState.IDLE -> Color(0xFF00B0FF)
                ZoyaState.STANDBY -> Color(0xFF00ACC1)
                ZoyaState.LISTENING -> Color(0xFF651FFF)
                ZoyaState.USER_SPEAKING -> Color(0xFF00B0FF)
                ZoyaState.THINKING -> Color(0xFFFF9100)
                ZoyaState.SPEAKING -> Color(0xFF00E676)
                ZoyaState.INTERRUPTED -> Color(0xFFFF5252)
                ZoyaState.ERROR -> Color(0xFFD32F2F)
            }

            // Live Audio Waveform Soundwave Ripples (reacts to user/Zoya voice in real-time)
            if (amplitude > 0.02f) {
                drawCircle(
                    color = coreOuterColor.copy(alpha = (amplitude * 0.6f).coerceIn(0.1f, 0.7f)),
                    center = center,
                    radius = currentRadius * (1.18f + amplitude * 0.5f),
                    style = Stroke(width = 3f + amplitude * 10f)
                )
                drawCircle(
                    color = coreInnerColor.copy(alpha = (amplitude * 0.4f).coerceIn(0.06f, 0.5f)),
                    center = center,
                    radius = currentRadius * (1.38f + amplitude * 0.85f),
                    style = Stroke(width = 2f + amplitude * 6f)
                )
            }

            // 1. Ambient Background Glow
            drawCircle(
                brush = androidx.compose.ui.graphics.Brush.radialGradient(
                    colors = listOf(coreOuterColor.copy(alpha = glowAlpha.value * 0.5f), Color.Transparent),
                    center = center,
                    radius = currentRadius * 2.5f
                ),
                radius = currentRadius * 2.5f
            )

            // 2. The Glass Sphere (Core)
            drawCircle(
                brush = androidx.compose.ui.graphics.Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.9f),
                        coreInnerColor.copy(alpha = 0.8f),
                        coreOuterColor.copy(alpha = 0.9f),
                        Color.Black.copy(alpha = 0.5f)
                    ),
                    center = androidx.compose.ui.geometry.Offset(center.x - currentRadius * 0.3f, center.y - currentRadius * 0.3f),
                    radius = currentRadius * 1.2f
                ),
                radius = currentRadius
            )
            
            // Inner Core Highlight for 3D effect
            drawCircle(
                color = Color.White.copy(alpha = 0.4f),
                center = androidx.compose.ui.geometry.Offset(center.x - currentRadius * 0.4f, center.y - currentRadius * 0.4f),
                radius = currentRadius * 0.3f
            )

            // 3. Neon Orbital Rings
            val ringRadiusX = currentRadius * 1.8f
            val ringRadiusY = currentRadius * 0.6f
            
            // Helper function to draw a 3D-ish ring
            fun drawNeonRing(angle: Float, startColor: Color, endColor: Color, strokeWidth: Float) {
                rotate(angle, center) {
                    drawOval(
                        brush = androidx.compose.ui.graphics.Brush.sweepGradient(
                            colors = listOf(startColor, endColor, startColor, Color.Transparent, startColor),
                            center = center
                        ),
                        topLeft = androidx.compose.ui.geometry.Offset(center.x - ringRadiusX, center.y - ringRadiusY),
                        size = androidx.compose.ui.geometry.Size(ringRadiusX * 2, ringRadiusY * 2),
                        style = Stroke(width = strokeWidth)
                    )
                    // Glow for the ring
                    drawOval(
                        color = startColor.copy(alpha = 0.3f),
                        topLeft = androidx.compose.ui.geometry.Offset(center.x - ringRadiusX, center.y - ringRadiusY),
                        size = androidx.compose.ui.geometry.Size(ringRadiusX * 2, ringRadiusY * 2),
                        style = Stroke(width = strokeWidth * 3)
                    )
                }
            }

            // Draw Rings
            val speedMultiplier = if (state == ZoyaState.THINKING || state == ZoyaState.SPEAKING) 2f else 1f
            
            // Red/Pink Ring
            drawNeonRing(ring1Angle.value * speedMultiplier, Color(0xFFFF1744), Color(0xFFD50000), 4f)
            
            // Green/Yellow Ring
            drawNeonRing(ring2Angle.value * speedMultiplier, Color(0xFF00E676), Color(0xFF76FF03), 4f)
            
            // Blue/Cyan Ring
            drawNeonRing(ring3Angle.value * speedMultiplier, Color(0xFF00E5FF), Color(0xFF2979FF), 4f)
            
            // Outer subtle glass ring
            drawNeonRing(ring4Angle.value * speedMultiplier, Color.White.copy(alpha = 0.5f), Color.White.copy(alpha = 0.1f), 2f)
            
            // 4. Outer Glass Dome Reflection
            drawCircle(
                brush = androidx.compose.ui.graphics.Brush.radialGradient(
                    colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.15f), Color.White.copy(alpha = 0.3f)),
                    center = center,
                    radius = currentRadius * 2.2f
                ),
                radius = currentRadius * 2.2f,
                style = Stroke(width = 2f)
            )
        }
    }
}

@Composable
fun LiveAudioWaveformBarVisualizer(
    state: ZoyaState,
    amplitude: Float,
    modifier: Modifier = Modifier
) {
    val barCount = 28
    val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition(label = "waveform_anim")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = androidx.compose.animation.core.LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    val primaryColor = when (state) {
        ZoyaState.USER_SPEAKING -> Color(0xFF00E5FF)
        ZoyaState.SPEAKING -> Color(0xFF00E676)
        ZoyaState.THINKING -> Color(0xFFFFD180)
        ZoyaState.LISTENING -> Color(0xFFB388FF)
        ZoyaState.STANDBY -> Color(0xFF80DEEA)
        ZoyaState.INTERRUPTED -> Color(0xFFFF5252)
        ZoyaState.ERROR -> Color(0xFFEF5350)
        ZoyaState.IDLE -> Color(0xFF80D8FF).copy(alpha = 0.35f)
    }

    val secondaryColor = when (state) {
        ZoyaState.USER_SPEAKING -> Color(0xFF2979FF)
        ZoyaState.SPEAKING -> Color(0xFF69F0AE)
        ZoyaState.THINKING -> Color(0xFFFF9100)
        ZoyaState.LISTENING -> Color(0xFF7C4DFF)
        ZoyaState.STANDBY -> Color(0xFF00ACC1)
        ZoyaState.INTERRUPTED -> Color(0xFFFF8A80)
        ZoyaState.ERROR -> Color(0xFFD32F2F)
        ZoyaState.IDLE -> Color(0xFF00B0FF).copy(alpha = 0.2f)
    }

    val statusBadge = when (state) {
        ZoyaState.USER_SPEAKING -> "🎤 Mic AudioRecord"
        ZoyaState.SPEAKING -> "🔊 Speaker AudioTrack"
        ZoyaState.THINKING -> "⚡ Processing Audio"
        ZoyaState.LISTENING -> "✦ Voice Activity Detector (VAD)"
        ZoyaState.STANDBY -> "✦ Standby ('Say Zoya')"
        ZoyaState.INTERRUPTED -> "⚡ Interrupted (Barge-in)"
        ZoyaState.ERROR -> "⚠ Link Offline"
        ZoyaState.IDLE -> "⏸ Standby"
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp)
    ) {
        // Waveform canvas
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(36.dp)
                .padding(horizontal = 6.dp)
        ) {
            val canvasWidth = size.width
            val canvasHeight = size.height
            val totalSpacing = canvasWidth * 0.25f
            val barWidth = (canvasWidth - totalSpacing) / barCount
            val barSpacing = totalSpacing / (barCount - 1)
            val centerY = canvasHeight / 2f

            for (i in 0 until barCount) {
                val normalizedIndex = i.toFloat() / (barCount - 1)
                val bell = Math.sin(normalizedIndex * Math.PI).toFloat()
                val ripple = kotlin.math.sin(phase + i * 0.45f).toFloat()
                val dynamicFactor = (bell * 0.65f + ripple * 0.35f).coerceIn(0.1f, 1f)

                val effectiveAmp = if (amplitude > 0.03f) {
                    (amplitude * 1.5f).coerceIn(0.15f, 1f)
                } else if (state == ZoyaState.LISTENING || state == ZoyaState.THINKING) {
                    0.12f + (kotlin.math.sin(phase * 2 + i * 0.3f) * 0.08f).toFloat()
                } else {
                    0.05f
                }

                val barHeight = ((canvasHeight * 0.85f) * dynamicFactor * effectiveAmp).coerceAtLeast(3f)
                val x = i * (barWidth + barSpacing)
                val top = centerY - barHeight / 2f

                drawRoundRect(
                    brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                        colors = listOf(primaryColor, secondaryColor)
                    ),
                    topLeft = androidx.compose.ui.geometry.Offset(x, top),
                    size = androidx.compose.ui.geometry.Size(barWidth, barHeight),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(barWidth / 2f, barWidth / 2f)
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Small indicator text
        Text(
            text = statusBadge,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = primaryColor.copy(alpha = 0.9f),
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun ChatScreen(onNavigateBack: () -> Unit) {
    val context = LocalContext.current
    val liveSessionManager = ZoyaForegroundService.activeService?.liveSessionManager
    val messages = liveSessionManager?.messages?.collectAsState(initial = emptyList())?.value ?: emptyList()

    androidx.compose.material3.Scaffold(
        containerColor = Color(0xFF1E1E2E),
        topBar = {
            androidx.compose.foundation.layout.Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                androidx.compose.material3.Button(
                    onClick = onNavigateBack,
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Color(0xFF80D8FF)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("Back", color = Color.Black)
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            Text(
                text = "State: ${ZoyaForegroundService.currentState.name}",
                color = Color(0xFF00E5FF),
                fontSize = 20.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages) { message ->
                    Text(
                        text = message,
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 16.sp
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))

            androidx.compose.material3.Button(
                onClick = { ZoyaForegroundService.activeService?.reconnectSession() },
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Color(0xFF80D8FF)),
                shape = RoundedCornerShape(24.dp)
            ) {
                Text("Reconnect", color = Color.Black)
            }
        }
    }
}

@Composable
fun ActionConfirmationCard(
    action: com.example.live.PendingAction,
    onConfirm: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    androidx.compose.material3.Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp),
        colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = Color(0xFF263238).copy(alpha = 0.95f)),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.5.dp, Color(0xFF00E5FF).copy(alpha = 0.7f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = when (action) {
                        is com.example.live.PendingAction.Call -> "📞 Call Confirmation"
                        is com.example.live.PendingAction.SendWhatsApp -> "💬 WhatsApp Message"
                        is com.example.live.PendingAction.DeleteMemory -> "🗑 Memory Deletion"
                    },
                    color = Color(0xFF00E5FF),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = when (action) {
                    is com.example.live.PendingAction.Call -> "Call ${action.contactName} (${action.phoneNumber})?"
                    is com.example.live.PendingAction.SendWhatsApp -> "Send to ${action.contactName}: \"${action.message}\"?"
                    is com.example.live.PendingAction.DeleteMemory -> "Remove from memory: \"${action.description}\"?"
                },
                color = Color.White,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(14.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onCancel) {
                    Text("Cancel", color = Color.White.copy(alpha = 0.7f))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onConfirm,
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Confirm", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

