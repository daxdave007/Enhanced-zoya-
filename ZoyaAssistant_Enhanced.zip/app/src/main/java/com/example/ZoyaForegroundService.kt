package com.example

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.AudioDeviceInfo
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.accessibility.ZoyaAccessibilityService
import com.example.live.LiveSessionManager
import com.example.live.ZoyaState
import com.example.proactive.ConversationMemory
import com.example.proactive.InteractionCooldownManager
import com.example.proactive.ProactiveDecisionEngine
import com.example.proactive.ProactiveEvent
import com.example.proactive.ProactiveEventType
import com.example.proactive.ZoyaPreferences
import com.example.tools.ToolExecutionEngine
import com.example.voice.AudioFocusController
import com.example.voice.VoiceActivityDetector
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class ZoyaForegroundService : Service() {

    private val job = Job()
    private val scope = CoroutineScope(Dispatchers.IO + job)

    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var echoCanceler: AcousticEchoCanceler? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var autoGainControl: AutomaticGainControl? = null

    private lateinit var audioFocusController: AudioFocusController
    private lateinit var vad: VoiceActivityDetector

    lateinit var liveSessionManager: LiveSessionManager
    private lateinit var toolEngine: ToolExecutionEngine
    private lateinit var preferences: ZoyaPreferences
    val conversationMemory = ConversationMemory()
    private val cooldownManager = InteractionCooldownManager()
    private var proactiveDecisionEngine: ProactiveDecisionEngine? = null

    private var isRecording = false

    // Configuration for Gemini Live Audio (16kHz, Mono, PCM 16-bit)
    private val sampleRate = 16000
    private val channelConfig = AudioFormat.CHANNEL_IN_MONO
    private val audioFormat = AudioFormat.ENCODING_PCM_16BIT
    private val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat) * 4

    // Configuration for audio output (24kHz, Mono, PCM 16-bit is typical for server output)
    private val outputSampleRate = 24000
    private val outChannelConfig = AudioFormat.CHANNEL_OUT_MONO
    private val outBufferSize = AudioTrack.getMinBufferSize(outputSampleRate, outChannelConfig, audioFormat) * 4

    companion object {
        var currentState: ZoyaState = ZoyaState.IDLE
            private set
        var onStateChange: ((ZoyaState) -> Unit)? = null

        private val _messages = kotlinx.coroutines.flow.MutableStateFlow<List<String>>(emptyList())
        val messages: kotlinx.coroutines.flow.StateFlow<List<String>> = _messages.asStateFlow()

        private val _audioAmplitude = kotlinx.coroutines.flow.MutableStateFlow(0f)
        val audioAmplitude: kotlinx.coroutines.flow.StateFlow<Float> = _audioAmplitude.asStateFlow()

        var activeRepository: com.example.data.ZoyaRepository? = null

        val pendingAction = kotlinx.coroutines.flow.MutableStateFlow<com.example.live.PendingAction?>(null)

        // Provide a way to send message from UI to active service if it exists
        var activeService: ZoyaForegroundService? = null

        fun stopPlaybackAndSpeech() {
            activeService?.let { service ->
                service.flushPlaybackImmediately()
                service.liveSessionManager.onStopRequested()
                service.resetProactiveTimer()
            }
        }
    }

    private var speechManager: com.example.voice.ZoyaSpeechManager? = null
    lateinit var smartMemoryManager: com.example.proactive.SmartMemoryManager
    lateinit var smartIntentDispatcher: com.example.tools.SmartIntentDispatcher

    @Volatile
    var lastUserInteractionTime = System.currentTimeMillis()
    private var proactiveInactivityJob: Job? = null

    fun resetProactiveTimer() {
        lastUserInteractionTime = System.currentTimeMillis()
    }

    override fun onCreate() {
        super.onCreate()
        try {
            activeService = this
            preferences = ZoyaPreferences.getInstance(this)

            val database = com.example.data.ZoyaDatabase.getDatabase(this)
            val repository = com.example.data.ZoyaRepository(database.zoyaDao())
            activeRepository = repository

            toolEngine = ToolExecutionEngine(this, repository) { base64 ->
                liveSessionManager.sendImageMedia(base64)
            }
            
            audioFocusController = AudioFocusController(this)
            audioFocusController.requestFocus()

            val onAudioOut: (ByteArray) -> Unit = { audioData ->
                playAudio(audioData)
            }
            
            val onInterruptOut: () -> Unit = {
                flushPlaybackImmediately()
            }
            
            liveSessionManager = LiveSessionManager(this, toolEngine, conversationMemory, repository, onAudioOut, onInterruptOut)

            scope.launch {
                repository.activeMemories.collect { memories ->
                    val adviceTexts = memories.map { it.content }
                    liveSessionManager.updateActiveAdvice(adviceTexts)
                }
            }

            vad = VoiceActivityDetector(
                sampleRate = sampleRate,
                frameSize = 1600,
                onSpeechStart = { preSpeechFrames ->
                    liveSessionManager.onUserSpeechStarted()
                    for (frame in preSpeechFrames) {
                        liveSessionManager.sendAudioData(frame, frame.size)
                    }
                },
                onSpeechChunk = { chunk, _ ->
                    liveSessionManager.sendAudioData(chunk, chunk.size)
                },
                onSpeechEnd = { _ ->
                    liveSessionManager.onUserSpeechEnded()
                },
                onBargeIn = {
                    flushPlaybackImmediately()
                    liveSessionManager.onLocalBargeIn()
                    liveSessionManager.onUserSpeechStarted()
                }
            )

            proactiveDecisionEngine = ProactiveDecisionEngine(
                context = this,
                preferences = preferences,
                conversationMemory = conversationMemory,
                cooldownManager = cooldownManager
            ) { prompt, screenSummary ->
                liveSessionManager.triggerProactiveSpeech(prompt, screenSummary)
            }

            ZoyaAccessibilityService.onProactiveEventListener = { event ->
                proactiveDecisionEngine?.evaluateEvent(event)
            }

            createNotificationChannel()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                try {
                    startForeground(1, createNotification(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
                } catch (e: Exception) {
                    try { startForeground(1, createNotification()) } catch(e: Exception) { }
                }
            } else {
                try { startForeground(1, createNotification()) } catch(e: Exception) { }
            }

            scope.launch {
                liveSessionManager.zoyaState.collect { state ->
                    currentState = state
                    onStateChange?.invoke(state)
                    updateNotification(state)
                }
            }
            scope.launch {
                liveSessionManager.messages.collect { msgList ->
                    _messages.value = msgList
                }
            }

            smartMemoryManager = com.example.proactive.SmartMemoryManager(repository)
            smartIntentDispatcher = com.example.tools.SmartIntentDispatcher(
                context = this,
                toolEngine = toolEngine,
                repository = repository,
                preferences = preferences,
                memoryManager = smartMemoryManager
            )
            scope.launch {
                smartIntentDispatcher.pendingAction.collect { action ->
                    pendingAction.value = action
                }
            }

            speechManager = com.example.voice.ZoyaSpeechManager(
                context = this,
                liveSessionManager = liveSessionManager,
                intentDispatcher = smartIntentDispatcher,
                onInterruptPlayback = { flushPlaybackImmediately() }
            )
            speechManager?.start()

            initAudioTrack()
            startMicrophoneLoop()
            // Establish the Live connection once, but remain in passive STANDBY.
            // Actual interaction starts only after the wake word "Zoya" is detected.
            liveSessionManager.enterStandby()
            liveSessionManager.startSession()
            startProactiveInactivityLoop()
        } catch (e: Exception) {
            Log.e("ZoyaService", "Error in onCreate", e)
        }
    }

    private fun startProactiveInactivityLoop() {
        proactiveInactivityJob?.cancel()
        proactiveInactivityJob = scope.launch(Dispatchers.Default) {
            while (isActive) {
                kotlinx.coroutines.delay(2000L)
                if (!preferences.proactiveEnabled.value) continue
                if (preferences.quietMode.value || conversationMemory.isQuietModeActive()) continue

                val state = liveSessionManager.zoyaState.value
                // Only evaluate when user has been silent and AI is not currently speaking, thinking, or receiving speech
                if (state == ZoyaState.SPEAKING || state == ZoyaState.THINKING || state == ZoyaState.USER_SPEAKING) {
                    lastUserInteractionTime = System.currentTimeMillis()
                    continue
                }

                val elapsed = System.currentTimeMillis() - lastUserInteractionTime
                if (elapsed >= 15_000L) {
                    lastUserInteractionTime = System.currentTimeMillis() // Reset timer
                    if (preferences.screenAwarenessEnabled.value && com.example.accessibility.ZoyaAccessibilityService.isServiceRunning()) {
                        val screenSnapshot = com.example.accessibility.ZoyaAccessibilityService.getCurrentScreenSnapshot()
                        if (screenSnapshot != null && !screenSnapshot.isSensitive && !screenSnapshot.isPasswordPresent) {
                            Log.d("ZoyaService", "15s inactivity reached - evaluating context on ${screenSnapshot.appName}")
                            val event = ProactiveEvent(
                                type = ProactiveEventType.USER_IDLE,
                                screenContext = screenSnapshot,
                                description = "User has been inactive for ~15 seconds on ${screenSnapshot.appName}"
                            )
                            proactiveDecisionEngine?.evaluateEvent(event)
                        }
                    }
                }
            }
        }
    }

    private val audioOutputQueue = java.util.concurrent.LinkedBlockingQueue<ByteArray>()
    private var isAudioPlaybackActive = false

    private fun flushPlaybackImmediately() {
        try {
            audioOutputQueue.clear()
            liveSessionManager.stopSpeechImmediately()
            if (audioTrack?.playState == AudioTrack.PLAYSTATE_PLAYING) {
                audioTrack?.pause()
                audioTrack?.flush()
                audioTrack?.play()
            }
        } catch (e: Exception) {
            Log.e("ZoyaDiagnostic", "Error flushing track on interrupt", e)
        }
        vad.isAiSpeaking = false
    }

    private fun startAudioPlaybackLoop() {
        isAudioPlaybackActive = true
        scope.launch(Dispatchers.IO) {
            var hadAudioInQueue = false
            var emptyQueueStartTime = 0L

            while (isActive && isAudioPlaybackActive) {
                try {
                    val data = audioOutputQueue.poll(40, TimeUnit.MILLISECONDS)
                    if (data != null) {
                        hadAudioInQueue = true
                        emptyQueueStartTime = 0L
                        vad.isAiSpeaking = true

                        liveSessionManager.latencyTracker.onPlaybackStarted()

                        // Calculate RMS amplitude for real-time waveform visualization
                        val sampleCount = data.size / 2
                        var sumSquares = 0.0
                        for (i in 0 until sampleCount) {
                            val low = data[i * 2].toInt() and 0xFF
                            val high = data[i * 2 + 1].toInt()
                            val sample = (high shl 8) or low
                            sumSquares += sample.toDouble() * sample.toDouble()
                        }
                        val rms = if (sampleCount > 0) Math.sqrt(sumSquares / sampleCount) else 0.0
                        val target = (rms / 3200.0).toFloat().coerceIn(0.08f, 1f)
                        _audioAmplitude.value = _audioAmplitude.value * 0.25f + target * 0.75f

                        if (audioTrack?.playState != AudioTrack.PLAYSTATE_PLAYING) {
                            audioTrack?.play()
                        }
                        audioTrack?.write(data, 0, data.size)
                    } else {
                        // Queue is empty. If we previously had audio, let buffer drain completely
                        if (hadAudioInQueue) {
                            if (emptyQueueStartTime == 0L) {
                                emptyQueueStartTime = System.currentTimeMillis()
                            } else if (System.currentTimeMillis() - emptyQueueStartTime > 200L) {
                                // Buffer drained + 200ms acoustic settling guard
                                hadAudioInQueue = false
                                emptyQueueStartTime = 0L
                                vad.isAiSpeaking = false
                                _audioAmplitude.value = 0f
                                liveSessionManager.onAudioPlaybackCompleted()
                            }
                        } else {
                            if (_audioAmplitude.value > 0.01f) {
                                _audioAmplitude.value *= 0.7f
                            } else {
                                _audioAmplitude.value = 0f
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e("ZoyaDiagnostic", "Playback loop error", e)
                }
            }
        }
    }

    private fun initAudioTrack() {
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (audioManager.mode != AudioManager.MODE_NORMAL) {
                audioManager.mode = AudioManager.MODE_NORMAL
            }
            val minBuf = AudioTrack.getMinBufferSize(outputSampleRate, outChannelConfig, audioFormat)
            val finalBuf = if (minBuf > 0) minBuf * 4 else 8192
            
            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(audioFormat)
                        .setSampleRate(outputSampleRate)
                        .setChannelMask(outChannelConfig)
                        .build()
                )
                .setBufferSizeInBytes(finalBuf)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            // Prefer the phone's built-in main loudspeaker. VOICE_COMMUNICATION
            // commonly routes to the earpiece/receiver on Android phones.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val outputManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val builtInSpeaker = outputManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
                    .firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                if (builtInSpeaker != null) {
                    val routed = audioTrack?.setPreferredDevice(builtInSpeaker) ?: false
                    Log.i("ZoyaAudio", "Preferred output = BUILTIN_SPEAKER, routed=$routed")
                }
            }

            audioTrack?.play()
            startAudioPlaybackLoop()
        } catch (e: Exception) {
            Log.e("ZoyaService", "Error initializing AudioTrack", e)
        }
    }

    private fun playAudio(data: ByteArray) {
        try {
            audioOutputQueue.offer(data)
        } catch (e: Exception) {
            Log.e("ZoyaDiagnostic", "Error queueing audio", e)
        }
    }

    private fun startMicrophoneLoop() {
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Log.e("ZoyaDiagnostic", "Missing RECORD_AUDIO permission")
            return
        }

        try {
            val minBuf = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
            val finalBuf = if (minBuf > 0) minBuf * 4 else 8192
            
            Log.i("ZoyaDiagnostic", "Starting microphone recording. bufSize=$finalBuf")

            val ctx = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                createAttributionContext("zoya_audio")
            } else {
                this
            }
            audioRecord = AudioRecord.Builder()
                .setContext(ctx)
                .setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(sampleRate)
                        .setChannelMask(channelConfig)
                        .setEncoding(audioFormat)
                        .build()
                )
                .setBufferSizeInBytes(finalBuf)
                .build()

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                Log.e("ZoyaDiagnostic", "AudioRecord initialization failed!")
                return
            }

            // Attach hardware acoustic effects to suppress background noise & cancel echo
            val sessionId = audioRecord?.audioSessionId ?: 0
            if (sessionId != 0) {
                if (AcousticEchoCanceler.isAvailable()) {
                    try {
                        echoCanceler = AcousticEchoCanceler.create(sessionId)?.apply {
                            enabled = true
                            Log.i("ZoyaAudio", "AcousticEchoCanceler enabled on session $sessionId")
                        }
                    } catch (e: Exception) {
                        Log.w("ZoyaAudio", "AcousticEchoCanceler failed to attach", e)
                    }
                }
                if (NoiseSuppressor.isAvailable()) {
                    try {
                        noiseSuppressor = NoiseSuppressor.create(sessionId)?.apply {
                            enabled = true
                            Log.i("ZoyaAudio", "NoiseSuppressor enabled on session $sessionId")
                        }
                    } catch (e: Exception) {
                        Log.w("ZoyaAudio", "NoiseSuppressor failed to attach", e)
                    }
                }
                if (AutomaticGainControl.isAvailable()) {
                    try {
                        autoGainControl = AutomaticGainControl.create(sessionId)?.apply {
                            enabled = true
                            Log.i("ZoyaAudio", "AutomaticGainControl enabled on session $sessionId")
                        }
                    } catch (e: Exception) {
                        Log.w("ZoyaAudio", "AutomaticGainControl failed to attach", e)
                    }
                }
            }

            audioRecord?.startRecording()
            isRecording = true

            scope.launch(Dispatchers.IO) {
                // 100ms of audio at 16kHz is 1600 samples
                val chunkSize = 1600
                val audioBuffer = ShortArray(chunkSize)
                var readCount = 0
                while (isActive && isRecording) {
                    try {
                        val readResult = audioRecord?.read(audioBuffer, 0, chunkSize) ?: 0
                        if (readResult > 0) {
                            if (readCount % 50 == 0) {
                                Log.v("ZoyaDiagnostic", "Microphone read loop active. readResult=$readResult")
                            }
                            readCount++

                            // Update live waveform amplitude for real-time visualization (AudioRecord input)
                            val currentState = liveSessionManager.zoyaState.value
                            if (currentState == ZoyaState.USER_SPEAKING || vad.isSpeaking) {
                                var sumSquares = 0.0
                                for (i in 0 until readResult) {
                                    val sample = audioBuffer[i].toDouble()
                                    sumSquares += sample * sample
                                }
                                val rms = Math.sqrt(sumSquares / readResult)
                                val target = (rms / 2800.0).toFloat().coerceIn(0.06f, 1f)
                                _audioAmplitude.value = _audioAmplitude.value * 0.3f + target * 0.7f
                            } else if (currentState != ZoyaState.SPEAKING) {
                                if (_audioAmplitude.value > 0.01f) {
                                    _audioAmplitude.value *= 0.65f
                                } else {
                                    _audioAmplitude.value = 0f
                                }
                            }

                            processAudio(audioBuffer, readResult)
                        } else {
                            Log.e("ZoyaDiagnostic", "Microphone read failed or empty: $readResult")
                        }
                    } catch (e: Exception) {
                        Log.e("ZoyaDiagnostic", "Error reading audio", e)
                    }
                }
                Log.i("ZoyaDiagnostic", "Microphone loop stopped.")
            }
        } catch (e: Exception) {
            Log.e("ZoyaDiagnostic", "Error starting microphone", e)
        }
    }

    private var lastFlushTime = 0L

    private fun processAudio(buffer: ShortArray, length: Int) {
        val state = liveSessionManager.zoyaState.value
        
        if (state == ZoyaState.IDLE || state == ZoyaState.STANDBY) {
            // Never reconnect automatically from the microphone loop.
            // This prevents Zoya from turning itself back on after the user stops it.
            vad.reset()
            return
        }

        // VoiceActivityDetector intelligently discriminates speech from background noise and handles barge-in
        vad.processFrame(buffer, length)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        // Do not let Android recreate Zoya after the user/process explicitly stops it.
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    fun sendTextMessage(text: String) {
        liveSessionManager.sendTextMessage(text)
    }

    fun reconnectSession() {
        liveSessionManager.startSession()
    }

    override fun onDestroy() {
        super.onDestroy()
        ZoyaAccessibilityService.onProactiveEventListener = null
        proactiveDecisionEngine = null
        activeService = null
        isRecording = false
        isAudioPlaybackActive = false
        proactiveInactivityJob?.cancel()
        currentState = ZoyaState.IDLE
        onStateChange?.invoke(currentState)
        audioOutputQueue.clear()

        try { echoCanceler?.release() } catch (e: Exception) {}
        try { noiseSuppressor?.release() } catch (e: Exception) {}
        try { autoGainControl?.release() } catch (e: Exception) {}
        audioFocusController.abandonFocus()

        speechManager?.destroy()
        speechManager = null
        try { audioRecord?.stop() } catch (e: Exception) {}
        try { audioRecord?.release() } catch (e: Exception) {}
        try { audioTrack?.stop() } catch (e: Exception) {}
        try { audioTrack?.release() } catch (e: Exception) {}
        try { liveSessionManager.stopSession() } catch (e: Exception) {}
        job.cancel()
    }

    private fun updateNotification(state: ZoyaState) {
        try {
            val manager = getSystemService(NotificationManager::class.java)
            manager?.notify(1, createNotification(state))
        } catch (e: Exception) {
            Log.e("ZoyaService", "Error updating notification", e)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                "ZOYA_CHANNEL",
                "Zoya Assistant Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(serviceChannel)
        }
    }

    private fun createNotification(state: ZoyaState = currentState): Notification {
        val (title, text) = when (state) {
            ZoyaState.STANDBY -> "Zoya Assistant • Standby" to "Say 'Zoya' to activate."
            ZoyaState.LISTENING -> "Zoya Assistant • Listening" to "Speak your command..."
            ZoyaState.USER_SPEAKING -> "Zoya Assistant" to "Hearing you..."
            ZoyaState.THINKING -> "Zoya Assistant" to "Thinking..."
            ZoyaState.SPEAKING -> "Zoya Assistant" to "Speaking response..."
            ZoyaState.INTERRUPTED -> "Zoya Assistant" to "Interrupted. Listening..."
            else -> "Zoya Assistant" to "Background assistant active."
        }

        return NotificationCompat.Builder(this, "ZOYA_CHANNEL")
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
}
