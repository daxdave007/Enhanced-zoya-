package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.proactive.ConversationMemory
import com.example.proactive.InteractionCooldownManager
import com.example.proactive.ProactiveEvent
import com.example.proactive.ProactiveEventType
import com.example.proactive.ScreenCategory
import com.example.proactive.ScreenContext
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Remix Zoya Assistant", appName)
  }

  @Test
  fun `conversation memory respects quiet commands`() {
    val memory = ConversationMemory()
    assertFalse(memory.isQuietModeActive())

    memory.addTurn("user", "stop talking and be quiet")
    assertTrue(memory.isQuietModeActive())

    memory.addTurn("user", "hey zoya, you can speak now")
    assertFalse(memory.isQuietModeActive())
  }

  @Test
  fun `cooldown manager prevents same screen repetition`() {
    val cooldown = InteractionCooldownManager()
    val screen = ScreenContext(
      packageName = "com.android.settings",
      appName = "Settings",
      windowTitle = "Developer options",
      visibleTexts = listOf("USB debugging", "Stay awake"),
      clickableLabels = listOf("USB debugging"),
      isSensitive = false,
      isPasswordPresent = false,
      contentHash = "test_hash_123"
    )
    val event = ProactiveEvent(ProactiveEventType.SCREEN_CHANGED, screen, "Settings opened")

    assertTrue(cooldown.canInterrupt(event))
    cooldown.recordInterruption(event)

    // Immediate second attempt on exact same screen should be blocked
    assertFalse(cooldown.canInterrupt(event))
  }

  @Test
  fun `voice activity detector ignores low background noise and single clicks`() {
    var speechStarted = false
    val vad = com.example.voice.VoiceActivityDetector(
      sampleRate = 16000,
      frameSize = 1600,
      onSpeechStart = { speechStarted = true },
      onSpeechChunk = { _, _ -> },
      onSpeechEnd = { },
      onBargeIn = { }
    )

    // Send 5 frames of low ambient noise (RMS ~100)
    val noiseBuffer = ShortArray(1600) { 100 }
    repeat(5) {
      vad.processFrame(noiseBuffer, noiseBuffer.size)
    }
    assertFalse("Ambient noise should not trigger speech", speechStarted)

    // Send a single high-energy click frame followed by silence
    val clickBuffer = ShortArray(1600) { 2000 }
    vad.processFrame(clickBuffer, clickBuffer.size)
    val silenceBuffer = ShortArray(1600) { 50 }
    vad.processFrame(silenceBuffer, silenceBuffer.size)
    assertFalse("Single pop/click should not trigger speech", speechStarted)
  }

  @Test
  fun `voice activity detector detects genuine sustained speech and barge-in`() {
    var speechStarted = false
    var bargeInDetected = false
    val vad = com.example.voice.VoiceActivityDetector(
      sampleRate = 16000,
      frameSize = 1600,
      onSpeechStart = { speechStarted = true },
      onSpeechChunk = { _, _ -> },
      onSpeechEnd = { },
      onBargeIn = { bargeInDetected = true }
    )

    // Send sustained loud speech frames (RMS ~2500)
    val speechBuffer = ShortArray(1600) { 2500 }
    vad.processFrame(speechBuffer, speechBuffer.size)
    vad.processFrame(speechBuffer, speechBuffer.size)
    assertTrue("Sustained speech must trigger speech started", speechStarted)

    // Now simulate AI speaking and test barge-in
    vad.reset()
    vad.isAiSpeaking = true
    vad.processFrame(speechBuffer, speechBuffer.size)
    vad.processFrame(speechBuffer, speechBuffer.size)
    assertTrue("Loud user speech while AI is speaking must trigger barge-in", bargeInDetected)
  }

  @Test
  fun `voice latency tracker computes end-to-playback turnaround`() {
    val tracker = com.example.voice.VoiceLatencyTracker()
    tracker.onUserSpeechStarted()
    tracker.onFirstAudioChunkSent()
    tracker.onUserSpeechEnded()
    tracker.onFirstServerAudioReceived()
    tracker.onPlaybackStarted()

    assertTrue(tracker.lastMeasuredLatencyMs >= 0)
    val summary = tracker.formatDiagnosticSummary()
    assertTrue(summary != null && summary.contains("Latency:"))
  }
}

