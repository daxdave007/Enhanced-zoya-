import os
import sys
import mimetypes
from http.server import HTTPServer, BaseHTTPRequestHandler

APK_PATH = "/app/applet/ZoyaAssistant.apk"
if not os.path.exists(APK_PATH):
    APK_PATH = "/app/applet/app/build/outputs/apk/debug/app-debug.apk"

apk_size = os.path.getsize(APK_PATH) if os.path.exists(APK_PATH) else 0

HTML_CONTENT = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download Zoya Assistant APK</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
        }}
        body {{
            background: radial-gradient(circle at 50% 10%, #1a103c 0%, #080711 100%);
            min-height: 100vh;
            color: #ffffff;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 24px;
            text-align: center;
        }}
        .card {{
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 28px;
            padding: 36px 28px;
            max-width: 440px;
            width: 100%;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.6), 0 0 40px rgba(138, 43, 226, 0.25);
            animation: fadeIn 0.8s cubic-bezier(0.16, 1, 0.3, 1);
        }}
        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(20px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}
        .orb {{
            width: 90px;
            height: 90px;
            margin: 0 auto 20px auto;
            border-radius: 50%;
            background: radial-gradient(circle at 35% 35%, #00f2fe, #4facfe 40%, #7f00ff 80%, #ff007f 100%);
            box-shadow: 0 0 35px rgba(79, 172, 254, 0.8), 0 0 60px rgba(127, 0, 255, 0.6);
            animation: pulse 3s infinite alternate ease-in-out;
        }}
        @keyframes pulse {{
            0% {{ transform: scale(0.96); filter: brightness(0.9); }}
            100% {{ transform: scale(1.05); filter: brightness(1.2); }}
        }}
        h1 {{
            font-size: 26px;
            font-weight: 800;
            letter-spacing: -0.5px;
            margin-bottom: 6px;
            background: linear-gradient(135deg, #ffffff 40%, #a5b4fc 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}
        .badge {{
            display: inline-block;
            background: rgba(99, 102, 241, 0.25);
            color: #c7d2fe;
            border: 1px solid rgba(129, 140, 248, 0.4);
            padding: 4px 12px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 18px;
        }}
        p.desc {{
            color: #94a3b8;
            font-size: 14px;
            line-height: 1.5;
            margin-bottom: 28px;
        }}
        .btn {{
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            background: linear-gradient(135deg, #6366f1 0%, #a855f7 100%);
            color: #ffffff;
            font-weight: 700;
            font-size: 16px;
            padding: 16px 24px;
            border-radius: 18px;
            text-decoration: none;
            box-shadow: 0 10px 25px rgba(99, 102, 241, 0.4);
            transition: all 0.2s ease;
            cursor: pointer;
            border: none;
            width: 100%;
        }}
        .btn:hover {{
            transform: translateY(-2px);
            box-shadow: 0 15px 30px rgba(168, 85, 247, 0.5);
        }}
        .btn:active {{
            transform: translateY(1px);
        }}
        .meta-info {{
            margin-top: 14px;
            font-size: 12px;
            color: #64748b;
        }}
        .steps {{
            margin-top: 28px;
            text-align: left;
            background: rgba(0, 0, 0, 0.25);
            border-radius: 16px;
            padding: 16px;
            font-size: 13px;
            color: #cbd5e1;
        }}
        .steps h3 {{
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            color: #94a3b8;
            margin-bottom: 10px;
        }}
        .steps ol {{
            padding-left: 20px;
            line-height: 1.7;
        }}
    </style>
</head>
<body>
    <div class="card">
        <div class="orb"></div>
        <h1>Zoya Assistant</h1>
        <div class="badge">Gemini Live Voice AI • v1.0.0</div>
        <p class="desc">Autonomous screen reader, live duplex voice, and proactive phone assistant ready for Android.</p>
        
        <a href="/ZoyaAssistant.apk" class="btn" download="ZoyaAssistant.apk">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                <polyline points="7 10 12 15 17 10"></polyline>
                <line x1="12" y1="15" x2="12" y2="3"></line>
            </svg>
            Download APK File (19 MB)
        </a>

        <div class="meta-info">Compatible with Android 8.0 to Android 15</div>

        <div class="steps">
            <h3>How to install on Android:</h3>
            <ol>
                <li>Tap <b>Download APK File</b> above.</li>
                <li>When download finishes, tap the notification or open <b>Downloads</b> in your Files app.</li>
                <li>Tap <b>Install</b> (if prompted, enable <i>Allow unknown sources</i>).</li>
                <li>Open <b>Zoya</b> and grant Microphone & Accessibility permissions.</li>
            </ol>
        </div>
    </div>
</body>
</html>
""".encode('utf-8')

ZIP_PATH = "/app/applet/ZoyaAssistant_Project.zip"

class ApkHandler(BaseHTTPRequestHandler):
    def do_HEAD(self):
        self.send_response(200)
        if self.path.endswith('.zip') or 'zip' in self.path.lower():
            size = os.path.getsize(ZIP_PATH) if os.path.exists(ZIP_PATH) else 0
            self.send_header("Content-Type", "application/zip")
            self.send_header("Content-Length", str(size))
            self.send_header("Content-Disposition", 'attachment; filename="ZoyaAssistant_Project.zip"')
        elif self.path.endswith('.apk') or self.path.startswith('/download'):
            self.send_header("Content-Type", "application/vnd.android.package-archive")
            self.send_header("Content-Length", str(apk_size))
            self.send_header("Content-Disposition", 'attachment; filename="ZoyaAssistant.apk"')
        else:
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(HTML_CONTENT)))
        self.end_headers()

    def do_GET(self):
        if self.path.endswith('.zip') or 'zip' in self.path.lower():
            if not os.path.exists(ZIP_PATH):
                self.send_error(404, "ZIP not found")
                return
            size = os.path.getsize(ZIP_PATH)
            self.send_response(200)
            self.send_header("Content-Type", "application/zip")
            self.send_header("Content-Disposition", 'attachment; filename="ZoyaAssistant_Project.zip"')
            self.send_header("Content-Length", str(size))
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            with open(ZIP_PATH, 'rb') as f:
                while chunk := f.read(65536):
                    try:
                        self.wfile.write(chunk)
                    except (BrokenPipeError, ConnectionResetError):
                        break
        elif self.path.endswith('.apk') or self.path == '/download' or 'apk' in self.path.lower():
            if not os.path.exists(APK_PATH):
                self.send_error(404, "APK not found")
                return
            size = os.path.getsize(APK_PATH)
            self.send_response(200)
            self.send_header("Content-Type", "application/vnd.android.package-archive")
            self.send_header("Content-Disposition", 'attachment; filename="ZoyaAssistant.apk"')
            self.send_header("Content-Length", str(size))
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            with open(APK_PATH, 'rb') as f:
                while chunk := f.read(65536):
                    try:
                        self.wfile.write(chunk)
                    except (BrokenPipeError, ConnectionResetError):
                        break
        else:
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(HTML_CONTENT)))
            self.end_headers()
            self.wfile.write(HTML_CONTENT)

    def log_message(self, format, *args):
        # Quiet logging
        pass

if __name__ == '__main__':
    server_address = ('0.0.0.0', 3000)
    httpd = HTTPServer(server_address, ApkHandler)
    print("Serving APK download web server on port 3000...")
    sys.stdout.flush()
    httpd.serve_forever()
