import os
import sys
from http.server import HTTPServer, SimpleHTTPRequestHandler

class CustomHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        if self.path.endswith('.apk'):
            self.send_header('Content-Type', 'application/vnd.android.package-archive')
            self.send_header('Content-Disposition', 'attachment; filename="ZoyaAssistant.apk"')
        elif self.path.endswith('.zip'):
            self.send_header('Content-Type', 'application/zip')
            self.send_header('Content-Disposition', 'attachment; filename="ZoyaAssistant_Project.zip"')
        super().end_headers()

if __name__ == '__main__':
    os.chdir('/app/applet')
    server = HTTPServer(('0.0.0.0', 3000), CustomHandler)
    server.serve_forever()
